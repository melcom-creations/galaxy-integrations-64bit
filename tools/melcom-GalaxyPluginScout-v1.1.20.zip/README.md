# melcom's Galaxy Plugin Scout

**melcom's Galaxy Plugin Scout** is a Windows PowerShell tool for analyzing a GOG Galaxy plugin folder, resolving its Python dependency tree, and preparing an update configuration for the plugin's bundled modules.

It is designed for GOG Galaxy 2.x plugins on 64-bit Windows with Python 3.13 in mind. The tool can also clean unused modules, create backups, write a `plugin-config.txt` file next to the script, and run in a safe dry-run mode before making any changes.

## What it does

The Scout walks through a plugin's `plugin.py` files and the `modules` folder, then classifies everything into a clear report:

- `KEEP` for direct imports, transitive dependencies, and alias-resolved packages
- `SKIP` for protected internal folders, local code, and binary-only content
- `REMOVE` for unused Python libraries that are present on disk but not needed at runtime

When run without dry-run mode, it can also remove unused modules, create a backup archive, and trigger the updater flow based on the generated config.

## Features

- Recursive dependency scanning across the plugin root and `modules`
- Import alias resolution for packages such as `attr` -> `attrs`, `yaml` -> `PyYAML`, and `dateutil` -> `python-dateutil`
- Protected namespace handling for internal plugin folders and non-Python content
- Dev-tool filtering to keep build and test packages out of runtime installs
- Optional backup creation before cleanup and update
- Automatic `plugin-config.txt` generation next to the script
- Structured execution logs under `logs`
- Normal run and full dry-run support
- English and German interactive prompts

## Requirements

- Windows 10 or Windows 11
- PowerShell 5.1 or newer
- A valid GOG Galaxy plugin folder
- GOG Galaxy 2.x plugin structure with at least `plugin.py` or `manifest.json`
- Python 3.13 64-bit libraries inside the plugin's `modules` folder

## Quick start

1. Copy the Scout files into one folder.
2. Double-click `GalaxyPluginScout.bat` to start the normal workflow.
3. Double-click `GalaxyPluginScout-DryRun.bat` to inspect the result without changing anything.
4. Enter the root path of your GOG Galaxy plugin when prompted.
5. Review the report and continue through the workflow.

The typical plugin path looks like this:

```text
%localappdata%\GOG.com\Galaxy\plugins\installed\<plugin_folder>
```

You can paste the path directly from File Explorer, and environment variables such as `%localappdata%` are expanded automatically.

## How to use

### Normal run

Use `GalaxyPluginScout.bat` when you want the full workflow:

```text
GalaxyPluginScout.bat
```

This launcher starts `GalaxyPluginScout.ps1` in PowerShell and runs the complete analysis, backup, cleanup, config generation, and updater flow.

### Dry-run mode

Use `GalaxyPluginScout-DryRun.bat` when you want a safe preview:

```text
GalaxyPluginScout-DryRun.bat
```

Dry-run mode performs the full scan and prints the complete `KEEP / SKIP / REMOVE` report, but it does not modify files, create a backup, delete modules, or invoke pip-related update actions.

### PowerShell launch

You can also start the script directly:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\GalaxyPluginScout.ps1
```

For a dry run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\GalaxyPluginScout.ps1 -DryRun
```

## Workflow overview

1. Select the language.
2. Enter the plugin root path.
3. Scan root `.py` files.
4. Map the contents of `modules`.
5. Resolve the dependency tree.
6. Print the report.
7. In normal mode, create a backup and remove unused modules.
8. Write `plugin-config.txt` next to the Scout script.
9. Run the updater step with the generated config.

## Output files

The Scout writes its support files next to the script, not inside the plugin folder:

- `plugin-config.txt`
- `backups`
- `logs`

Backups are timestamped and stored per plugin name so that previous archives are not overwritten.

## Notes

- The tool validates that the selected folder is a real GOG Galaxy plugin root by checking for `plugin.py` or `manifest.json`.
- The report separates direct imports, transitive dependencies, alias-resolved packages, protected items, and unused libraries.
- The dry-run banner makes it obvious when no changes will be made.
- The tool is written for PowerShell and Windows console usage.

## Changelog

See `CHANGELOG.md` for the full release history and technical fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for details.

---

If you use this tool on an existing plugin, start with dry-run mode first, then move to a normal run once the report looks correct.
