#Requires -Version 5.1
<#
.SYNOPSIS
    melcom's Galaxy Plugin Scout  -  Analyzer & Updater
    Version 1.1.20  |  For GOG Galaxy 2.x  (64-bit, Python 3.13)
.NOTES
    Author  : melcom  (tooling by Claude / Anthropic)
    Created : 2026-06-27
    Target  : Windows 10/11, PowerShell 5.1+
#>

param(
    [switch]$DryRun
)

Set-StrictMode -Off
$ErrorActionPreference = 'Continue'

# ---------------------------------------------------------------------------
# Logging
# Writes colored output to the console and a plain-text copy to a log file.
# ---------------------------------------------------------------------------
$global:LogFile  = $null
$global:PathError = $null

function Write-Msg {
    param(
        [Parameter(ValueFromPipeline=$true, Position=0)]
        [string]$Text = "",
        [switch]$NoNewline,
        [switch]$LogOnly
    )

    if (-not $LogOnly) {
        if ($NoNewline) { Write-Host $Text -NoNewline }
        else            { Write-Host $Text }
    }

    if ($global:LogFile) {
        $clean = $Text -replace '\x1B\[[0-9;]*m', ''
        if ($NoNewline) {
            [System.IO.File]::AppendAllText($global:LogFile, $clean, [System.Text.Encoding]::UTF8)
        } else {
            [System.IO.File]::AppendAllText($global:LogFile, $clean + [Environment]::NewLine, [System.Text.Encoding]::UTF8)
        }
    }
}

function Read-Msg {
    param([string]$Prompt)
    $ans = (Read-Host $Prompt).Trim()
    if ($global:LogFile) {
        $cleanPrompt = $Prompt -replace '\x1B\[[0-9;]*m', ''
        [System.IO.File]::AppendAllText($global:LogFile, "${cleanPrompt}: $ans" + [Environment]::NewLine, [System.Text.Encoding]::UTF8)
    }
    return $ans
}

# ---------------------------------------------------------------------------
# ANSI color helpers
# ---------------------------------------------------------------------------
$ESC = [char]27
function clr     { param($code,$txt); return "$ESC[${code}m${txt}${ESC}[0m" }
function Red     ($t){ clr '91' $t }
function Green   ($t){ clr '92' $t }
function Yellow  ($t){ clr '93' $t }
function Cyan    ($t){ clr '96' $t }
function White   ($t){ clr '97' $t }
function Bold    ($t){ clr '1'  $t }
function Dim     ($t){ clr '2'  $t }
function Magenta ($t){ clr '95' $t }

# ---------------------------------------------------------------------------
# Globals
# ---------------------------------------------------------------------------
$TOOL_NAME    = "melcom's Galaxy Plugin Scout"
$TOOL_VERSION = "v1.1.20"

# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------
function Show-Banner {
    Clear-Host
    Write-Msg ""
    Write-Msg (Bold (Cyan "  +==============================================================+"))
    Write-Msg (Bold (Cyan "  |       melcom's Galaxy Plugin Scout  v1.1.20                  |"))
    Write-Msg (Bold (Cyan "  |       GOG Galaxy 2.x  |  Python 3.13  |  64-bit              |"))
    Write-Msg (Bold (Cyan "  +==============================================================+"))
    Write-Msg ""
}

# ---------------------------------------------------------------------------
# Language selector
# Redraws the banner on invalid input instead of just printing an error below.
# ---------------------------------------------------------------------------
function Select-Language {
    $choice   = ""
    $errorMsg = $null

    while ($choice -ne '1' -and $choice -ne '2') {
        Show-Banner
if ($DryRun) {
    Write-Host "===============================================" -ForegroundColor Yellow
    Write-Host "              *** DRY-RUN MODE ***" -ForegroundColor Black -BackgroundColor Yellow
    Write-Host "      No files will be modified in this run." -ForegroundColor Yellow
    Write-Host "===============================================" -ForegroundColor Yellow
}
        Write-Msg (Yellow "  Select language / Sprache waehlen:")
        Write-Msg        "    [1]  English"
        Write-Msg        "    [2]  Deutsch"
        Write-Msg ""

        if ($errorMsg) {
            Write-Msg (Red "  [!] $errorMsg")
            Write-Msg ""
            $errorMsg = $null
        }

        $choice = Read-Msg "  > Your choice / Ihre Wahl [1/2]"

        if ($choice -ne '1' -and $choice -ne '2') {
            $errorMsg = "Only 1 or 2 are allowed. / Nur 1 oder 2 sind erlaubt."
        }
    }
    return $choice
}

# ---------------------------------------------------------------------------
# Greeting
# ---------------------------------------------------------------------------
function Show-Greeting {
    param($lang)
    Write-Msg ""
    if ($lang -eq '1') {
        Write-Msg (Green "  Welcome to Galaxy Plugin Scout.")
        Write-Msg        "  This tool analyses your GOG Galaxy plugin folder,"
        Write-Msg        "  maps all modules, resolves the dependency tree,"
        Write-Msg        "  and can update all libraries to their latest versions."
    } else {
        Write-Msg (Green "  Willkommen beim Galaxy Plugin Scout.")
        Write-Msg        "  Dieses Tool analysiert deinen GOG Galaxy Plugin-Ordner,"
        Write-Msg        "  kartiert alle Module, loest den Abhaengigkeitsbaum auf,"
        Write-Msg        "  und kann alle Bibliotheken auf den neuesten Stand bringen."
    }
    Write-Msg ""
}

# ---------------------------------------------------------------------------
# Plugin root path prompt
# Accepts %env% variables in the input. Validates that the folder exists and
# contains at least plugin.py or manifest.json so we know it is a plugin root.
# On a bad entry the screen is redrawn cleanly instead of appending errors.
# ---------------------------------------------------------------------------
function Get-PluginRoot {
    param($lang)

    $raw        = ""
    $isFirstRun = $true

    while ($true) {
        if (-not $isFirstRun) { Show-Banner }
        $isFirstRun = $false

        if ($lang -eq '1') {
            Write-Msg (Yellow "  Enter the ROOT path of your GOG Galaxy plugin folder.")
            Write-Msg (Dim   "  Typical location:")
            Write-Msg (Dim   "    %localappdata%\GOG.com\Galaxy\plugins\installed\<plugin_folder>")
            Write-Msg (Dim   "    You can also paste the path directly from the Explorer address bar.")
        } else {
            Write-Msg (Yellow "  Bitte den ROOT-Pfad des GOG Galaxy Plugin-Ordners eingeben.")
            Write-Msg (Dim   "  Typischer Speicherort:")
            Write-Msg (Dim   "    %localappdata%\GOG.com\Galaxy\plugins\installed\<plugin_ordner>")
            Write-Msg (Dim   "    Den Pfad einfach aus der Adressleiste des Explorers einfuegen.")
        }
        Write-Msg ""

        if ($global:PathError) {
            Write-Msg (Red "  [!] $global:PathError")
            Write-Msg ""
            $global:PathError = $null
        }

        if ($lang -eq '1') {
            $raw = (Read-Msg "  > Path").Trim('"').TrimEnd('\')
        } else {
            $raw = (Read-Msg "  > Pfad").Trim('"').TrimEnd('\')
        }

        if (-not $raw) {
            if ($lang -eq '1') { $global:PathError = "Path cannot be empty. Please enter a valid directory." }
            else               { $global:PathError = "Der Pfad darf nicht leer sein. Bitte ein Verzeichnis eingeben." }
            continue
        }

        # Expand %LOCALAPPDATA% and similar environment variables
        $raw = [System.Environment]::ExpandEnvironmentVariables($raw)

        if (-not (Test-Path $raw -PathType Container)) {
            if ($lang -eq '1') { $global:PathError = "Directory not found: $raw" }
            else               { $global:PathError = "Verzeichnis nicht gefunden: $raw" }
            continue
        }

        # Verify this is a GOG plugin root (must contain plugin.py or manifest.json)
        $hasPluginPy     = Test-Path (Join-Path $raw 'plugin.py')      -PathType Leaf
        $hasManifestJson = Test-Path (Join-Path $raw 'manifest.json')   -PathType Leaf

        if (-not $hasPluginPy -and -not $hasManifestJson) {
            if ($lang -eq '1') {
                $global:PathError = "The folder contains neither 'plugin.py' nor 'manifest.json'. Please select a valid GOG plugin root."
            } else {
                $global:PathError = "Der Ordner enthaelt weder 'plugin.py' noch 'manifest.json'. Das ist kein gueltiger GOG-Plugin-Root-Ordner."
            }
            continue
        }

        break
    }
    return $raw + '\'
}

# ---------------------------------------------------------------------------
# Step header
# ---------------------------------------------------------------------------
function Write-StepHeader {
    param($step, $total, $title)
    Write-Msg ""
    Write-Msg (Cyan "  ================================================================")
    Write-Msg (Bold (Cyan "   [$step/$total] $title"))
    Write-Msg (Cyan "  ================================================================")
    Write-Msg ""
}

# ---------------------------------------------------------------------------
# Collect .py files in ROOT only (excludes /modules/)
# ---------------------------------------------------------------------------
function Get-RootPyFiles {
    param($rootPath)
    $modulesDir = Join-Path $rootPath 'modules'
    $all = Get-ChildItem -Path $rootPath -Filter '*.py' -Recurse -File -ErrorAction SilentlyContinue
    return @($all | Where-Object { $_.FullName -notlike ($modulesDir + '*') })
}

# ---------------------------------------------------------------------------
# Collect ALL .py files recursively including /modules/
# Used to build the full transitive import set.
# ---------------------------------------------------------------------------
function Get-AllPyFiles {
    param($rootPath)
    return @(Get-ChildItem -Path $rootPath -Filter '*.py' -Recurse -File -ErrorAction SilentlyContinue)
}

# ---------------------------------------------------------------------------
# Parse import statements from a list of .py files.
# Filters out a package's own self-imports so internal relative imports
# inside a library do not count as external dependencies.
# ---------------------------------------------------------------------------
function Get-Imports {
    param($pyFiles, $rootPath)

    $imports    = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $rxImport   = [regex]'^\s*import\s+([\w\.]+)'
    $rxFrom     = [regex]'^\s*from\s+([\w\.]+)\s+import'
    $modulesDir = Join-Path $rootPath 'modules'

    foreach ($f in $pyFiles) {
        # Determine which package this file belongs to (if inside /modules/)
        $currentPackage = $null
        if ($f.FullName -like ($modulesDir + '*')) {
            $relPath = $f.FullName.Substring($modulesDir.Length).TrimStart('\')
            $currentPackage = ($relPath -split '\\')[0]
            if ($currentPackage -match '\.py$') {
                $currentPackage = [System.IO.Path]::GetFileNameWithoutExtension($currentPackage)
            }
        }

        $lines = Get-Content $f.FullName -ErrorAction SilentlyContinue
        if (-not $lines) { continue }

        foreach ($line in $lines) {
            $m = $rxImport.Match($line)
            if ($m.Success) {
                $imp = ($m.Groups[1].Value -split '\.')[0]
                if (-not $currentPackage -or ($imp -ne $currentPackage)) {
                    [void]$imports.Add($imp)
                }
            }
            $m = $rxFrom.Match($line)
            if ($m.Success) {
                $imp = ($m.Groups[1].Value -split '\.')[0]
                if ($imp -and $imp -notmatch '^\.') {
                    if (-not $currentPackage -or ($imp -ne $currentPackage)) {
                        [void]$imports.Add($imp)
                    }
                }
            }
        }
    }
    return $imports
}

# ---------------------------------------------------------------------------
# Map /modules/ directory into typed buckets:
#   PythonPackages  - folders that contain .py or .pyd files
#   DistInfos       - <pkg>-<ver>.dist-info metadata folders
#   Singles         - standalone .py or .pyd files at the modules root
#   NonPython       - everything else (binary blobs, data dirs, etc.)
# ---------------------------------------------------------------------------
function Get-ModulesMap {
    param($rootPath)

    $modulesDir = Join-Path $rootPath 'modules'

    $result = @{
        PythonPackages = [ordered]@{}
        DistInfos      = [ordered]@{}
        NonPython      = New-Object 'System.Collections.Generic.List[string]'
        Singles        = [ordered]@{}
    }

    if (-not (Test-Path $modulesDir)) { return $result }

    foreach ($item in (Get-ChildItem -Path $modulesDir -ErrorAction SilentlyContinue)) {
        if ($item.Name -match '\.dist-info$') {
            $pkgName = ($item.Name -replace '-[^-]+\.dist-info$', '')
            $result.DistInfos[$item.Name] = $pkgName
        }
        elseif ($item.PSIsContainer) {
            $pyCount  = (Get-ChildItem $item.FullName -Filter '*.py'  -Recurse -ErrorAction SilentlyContinue).Count
            $pydCount = (Get-ChildItem $item.FullName -Filter '*.pyd' -Recurse -ErrorAction SilentlyContinue).Count
            if ($pyCount -gt 0 -or $pydCount -gt 0) {
                $hasInit = Test-Path (Join-Path $item.FullName '__init__.py')
                $result.PythonPackages[$item.Name] = @{ Path=$item.FullName; HasInit=$hasInit }
            } else {
                $result.NonPython.Add($item.Name)
            }
        }
        elseif ($item.Extension -in @('.py','.pyd')) {
            $result.Singles[$item.BaseName] = $item.FullName
        }
        else {
            $result.NonPython.Add($item.Name)
        }
    }
    return $result
}

# ---------------------------------------------------------------------------
# Resolve the full dependency tree.
#
# Classification buckets:
#   Direct        - imported directly by the plugin's own root .py files
#   Transitive    - not in root imports but used somewhere inside /modules/
#   AliasResolved - import name differs from the PyPI package name (e.g. attr -> attrs)
#   ProtectedKept - non-Python dirs, galaxy internals, binary blobs
#   ToRemove      - present in /modules/ but never imported anywhere
#
# Dev-tool blacklist:
#   Build and test packages (pytest, pip, setuptools, ...) are always marked
#   for removal even if the BFS scanner finds a transitive import path to them,
#   because those packages import each other and would otherwise create a
#   circular false-positive.
# ---------------------------------------------------------------------------
function Resolve-DependencyTree {
    param($rootImports, $allImports, $modulesMap)

    # Maps import-time names to their real PyPI distribution names
    $aliases = @{
        'attr'     = 'attrs'
        'yaml'     = 'PyYAML'
        'PIL'      = 'Pillow'
        'cv2'      = 'opencv-python'
        'bs4'      = 'beautifulsoup4'
        'sklearn'  = 'scikit-learn'
        'dateutil' = 'python-dateutil'
        'google'   = 'protobuf'
        'galaxy'   = 'galaxy_plugin_api'
    }

    # Expand the full import set with alias targets so that e.g. 'attr' being
    # imported also marks 'attrs' as referenced, preventing false REMOVE hits.
    $expandedImports = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($imp in $allImports) {
        [void]$expandedImports.Add($imp)
        if ($aliases.ContainsKey($imp)) { [void]$expandedImports.Add($aliases[$imp]) }
    }
    foreach ($imp in $rootImports) {
        [void]$expandedImports.Add($imp)
        if ($aliases.ContainsKey($imp)) { [void]$expandedImports.Add($aliases[$imp]) }
    }

    $allModuleKeys = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($k in $modulesMap.PythonPackages.Keys) { [void]$allModuleKeys.Add($k) }
    foreach ($k in $modulesMap.Singles.Keys)        { [void]$allModuleKeys.Add($k) }

    $stdlib = @(
        'os','sys','re','json','time','datetime','logging','pathlib','shutil',
        'subprocess','collections','itertools','functools','threading','asyncio',
        'typing','abc','io','math','hashlib','hmac','base64','copy','struct',
        'socket','ssl','http','urllib','email','html','xml','csv','sqlite3',
        'configparser','argparse','traceback','inspect','platform','uuid',
        'contextlib','dataclasses','enum','queue','weakref','gc','signal',
        'glob','fnmatch','tempfile','zipfile','tarfile','gzip','zlib',
        'random','secrets','string','textwrap','unicodedata','codecs',
        'builtins','warnings','unittest','ctypes','winreg','msvcrt',
        'concurrent','multiprocessing','pickle','array','decimal',
        'fractions','statistics','heapq','bisect','pprint','distutils',
        'importlib','pkg_resources','site','atexit','ntpath','posixpath',
        'numbers','operator','reprlib','types','token','tokenize','errno',
        'locale','gettext','binascii'
    )

    # Galaxy internals and binary-only dirs that must never be removed
    $protectedNamespaces = @('galaxy_api','bnet','bin','splash')

    # Dev / build / test packages that are never needed at plugin runtime
    $devToolsBlacklist = @(
        'pytest','_pytest','py','pluggy','iniconfig','atomicwrites',
        'pip','pip_tools','setuptools','wheel','piptools','pep517',
        'click','colorama','invoke','pyparsing','build','pyproject_hooks',
        '_distutils_hack','importlib_metadata','zipp','tomli',
        'asynctest','mypy_extensions'
    )

    $direct        = New-Object 'System.Collections.Generic.List[string]'
    $transitive    = New-Object 'System.Collections.Generic.List[string]'
    $aliasResolved = New-Object 'System.Collections.Generic.List[string]'
    $protectedKept = New-Object 'System.Collections.Generic.List[string]'
    $toRemove      = New-Object 'System.Collections.Generic.List[string]'

    # Pass 1: classify direct imports from the plugin's root files
    foreach ($imp in $rootImports) {
        if ($imp -in $stdlib)             { continue }
        if ($imp -in $protectedNamespaces) {
            if (-not $protectedKept.Contains($imp)) { $protectedKept.Add($imp) }
            continue
        }
        if ($allModuleKeys.Contains($imp)) {
            if (-not $direct.Contains($imp)) { $direct.Add($imp) }
            continue
        }
        if ($aliases.ContainsKey($imp)) {
            $real = $aliases[$imp]
            if ($allModuleKeys.Contains($real)) {
                if (-not $aliasResolved.Contains($imp))  { $aliasResolved.Add($imp) }
                if (-not $aliasResolved.Contains($real)) { $aliasResolved.Add($real) }
            }
        }
    }

    # Pass 2: classify everything else found across the full project scan
    foreach ($pkg in $modulesMap.PythonPackages.Keys) {
        if ($pkg -in $protectedNamespaces) {
            if (-not $protectedKept.Contains($pkg)) { $protectedKept.Add($pkg) }
            continue
        }
        if ($pkg -in $devToolsBlacklist) {
            if (-not $toRemove.Contains($pkg)) { $toRemove.Add($pkg) }
            continue
        }
        if ($direct.Contains($pkg) -or $aliasResolved.Contains($pkg)) { continue }

        if ($expandedImports.Contains($pkg)) {
            $transitive.Add($pkg)
        } else {
            if (-not $toRemove.Contains($pkg)) { $toRemove.Add($pkg) }
        }
    }

    foreach ($s in $modulesMap.Singles.Keys) {
        if ($s -in $protectedNamespaces) {
            if (-not $protectedKept.Contains($s)) { $protectedKept.Add($s) }
            continue
        }
        if ($s -in $devToolsBlacklist) {
            if (-not $toRemove.Contains($s)) { $toRemove.Add($s) }
            continue
        }
        if ($direct.Contains($s) -or $aliasResolved.Contains($s) -or $transitive.Contains($s)) { continue }

        # Strip compiled-extension suffix before matching (e.g. foo.cp313-win.* -> foo)
        $cleanS = $s -replace '\.cp\d+-win.*$', ''
        if ($expandedImports.Contains($s) -or $expandedImports.Contains($cleanS)) {
            $transitive.Add($s)
        } else {
            if (-not $toRemove.Contains($s)) { $toRemove.Add($s) }
        }
    }

    foreach ($np in $modulesMap.NonPython) {
        if (-not $protectedKept.Contains($np)) { $protectedKept.Add($np) }
    }

    return @{
        Direct        = $direct
        Transitive    = $transitive
        AliasResolved = $aliasResolved
        ProtectedKept = $protectedKept
        ToRemove      = $toRemove
    }
}

# ---------------------------------------------------------------------------
# Print the full analysis report
# ---------------------------------------------------------------------------
function Write-Report {
    param($rootPath, $pyFiles, $modulesMap, $tree, $lang)

    $modulesDir  = Join-Path $rootPath 'modules'
    $totalPython = $modulesMap.PythonPackages.Count + $modulesMap.Singles.Count

    Write-Msg ""
    Write-Msg (Cyan "  ================================================================")
    Write-Msg (Bold (White "   ANALYSIS REPORT  --  $TOOL_NAME $TOOL_VERSION"))
    Write-Msg (Cyan "  ================================================================")
    Write-Msg ""
    Write-Msg ("  ROOT path  : " + (White $rootPath))

    if (Test-Path $rootPath) {
        Write-Msg ("  " + (Green "[OK]") + " ROOT    : " + (White $rootPath))
    } else {
        Write-Msg ("  " + (Red  "[!!]") + " ROOT    : " + (White $rootPath))
    }
    if (Test-Path $modulesDir) {
        Write-Msg ("  " + (Green "[OK]") + " Modules : " + (White $modulesDir))
    } else {
        Write-Msg ("  " + (Yellow "[--]") + " Modules : " + (White $modulesDir))
    }
    Write-Msg ""

    if ($lang -eq '1') { $t = 'Scanning .py files in ROOT...' } else { $t = 'Scanne .py-Dateien im ROOT...' }
    Write-StepHeader '1' '4' $t
    if ($lang -eq '1') {
        Write-Msg ("  " + (Green "Found") + " " + (White "$($pyFiles.Count)") + " .py file(s).")
    } else {
        Write-Msg ("  " + (Green "Gefunden:") + " " + (White "$($pyFiles.Count)") + " .py-Datei(en).")
    }
    foreach ($f in $pyFiles) { Write-Msg ("    " + (Dim $f.Name)) }

    if ($lang -eq '1') { $t = '/modules/ content map' } else { $t = '/modules/ Inhalts-Karte' }
    Write-StepHeader '2' '4' $t
    Write-Msg ("  " + (Cyan "Python items") + " : " + (White "$totalPython"))
    Write-Msg ("  " + (Cyan "Dist-Infos  ") + " : " + (White "$($modulesMap.DistInfos.Count)"))
    Write-Msg ("  " + (Cyan "Non-Python  ") + " : " + (White "$($modulesMap.NonPython.Count)"))

    if ($lang -eq '1') { $t = 'Resolving full dependency tree...' } else { $t = 'Abhaengigkeitsbaum aufloesen...' }
    Write-StepHeader '3' '4' $t
    if ($lang -eq '1') {
        Write-Msg ("  " + (Green "Direct dependencies kept    ") + " : " + (White "$($tree.Direct.Count)"))
        Write-Msg ("  " + (Green "Transitive dependencies kept") + " : " + (White "$($tree.Transitive.Count)"))
        Write-Msg ("  " + (Yellow "Alias-resolved kept         ") + " : " + (White "$($tree.AliasResolved.Count)"))
        Write-Msg ("  " + (Red   "To remove                   ") + " : " + (White "$($tree.ToRemove.Count)"))
    } else {
        Write-Msg ("  " + (Green "Direkte Abhaengigkeiten    ") + " : " + (White "$($tree.Direct.Count)"))
        Write-Msg ("  " + (Green "Transitive Abhaengigkeiten ") + " : " + (White "$($tree.Transitive.Count)"))
        Write-Msg ("  " + (Yellow "Alias-aufgeloest           ") + " : " + (White "$($tree.AliasResolved.Count)"))
        Write-Msg ("  " + (Red   "Zu entfernen               ") + " : " + (White "$($tree.ToRemove.Count)"))
    }
    Write-Msg ""

    if ($tree.Direct.Count -gt 0) {
        if ($lang -eq '1') { $lbl = "KEEP  - Direct imports ($($tree.Direct.Count)):" }
        else               { $lbl = "KEEP  - Direkte Importe ($($tree.Direct.Count)):" }
        Write-Msg ("  " + (Bold (Green $lbl)))
        foreach ($d in ($tree.Direct | Sort-Object)) { Write-Msg ("    " + (Green "[+]") + " $d") }
        Write-Msg ""
    }

    if ($tree.Transitive.Count -gt 0) {
        if ($lang -eq '1') { $lbl = "KEEP  - Transitive & METADATA Dependencies ($($tree.Transitive.Count)):" }
        else               { $lbl = "KEEP  - Transitive & METADATA Abhaengigkeiten ($($tree.Transitive.Count)):" }
        Write-Msg ("  " + (Bold (Cyan $lbl)))
        foreach ($t2 in ($tree.Transitive | Sort-Object)) { Write-Msg ("    " + (Cyan "[~]") + " $t2") }
        Write-Msg ""
    }

    if ($tree.AliasResolved.Count -gt 0) {
        if ($lang -eq '1') { $lbl = "KEEP  - Alias-resolved ($($tree.AliasResolved.Count)):" }
        else               { $lbl = "KEEP  - Alias-aufgeloest ($($tree.AliasResolved.Count)):" }
        Write-Msg ("  " + (Bold (Yellow $lbl)))
        foreach ($a in ($tree.AliasResolved | Sort-Object)) { Write-Msg ("    " + (Yellow "[a]") + " $a") }
        Write-Msg ""
    }

    if ($tree.ProtectedKept.Count -gt 0) {
        if ($lang -eq '1') { $lbl = "SKIP  - Protected / Internal ($($tree.ProtectedKept.Count)):" }
        else               { $lbl = "SKIP  - Geschuetzt / Intern ($($tree.ProtectedKept.Count)):" }
        Write-Msg ("  " + (Bold (Magenta $lbl)))
        foreach ($n in ($tree.ProtectedKept | Sort-Object)) { Write-Msg ("    " + (Magenta "[!]") + " $n") }
        Write-Msg ""
    }

    if ($tree.ToRemove.Count -gt 0) {
        if ($lang -eq '1') { $lbl = "REMOVE - Unused Python lib ($($tree.ToRemove.Count)):" }
        else               { $lbl = "REMOVE - Ungenutzte Python-Lib ($($tree.ToRemove.Count)):" }
        Write-Msg ("  " + (Bold (Red $lbl)))
        foreach ($r in ($tree.ToRemove | Sort-Object)) { Write-Msg ("    " + (Red "[-]") + " $r") }
    } else {
        if ($lang -eq '1') { $lbl = "REMOVE - Unused Python lib (0)  -- nothing to remove" }
        else               { $lbl = "REMOVE - Ungenutzte Python-Lib (0)  -- nichts zu entfernen" }
        Write-Msg ("  " + (Bold (Red $lbl)))
    }
    Write-Msg ""
    Write-Msg (Cyan "  ================================================================")
}

# ---------------------------------------------------------------------------
# Backup
# Zips the /modules/ folder into a timestamped archive next to this script.
# ---------------------------------------------------------------------------
function New-Backup {
    param($rootPath, $lang)

    if ($lang -eq '1') {
        $ask = Read-Msg (Yellow "  Create a backup of the /modules/ folder? [Y/N]")
        $yes = ($ask -eq 'Y' -or $ask -eq 'y')
    } else {
        $ask = Read-Msg (Yellow "  Backup des /modules/-Ordners anlegen? [J/N]")
        $yes = ($ask -eq 'J' -or $ask -eq 'j' -or $ask -eq 'Y' -or $ask -eq 'y')
    }
    if (-not $yes) { return $null }

    $modulesDir = Join-Path $rootPath 'modules'
    if (-not (Test-Path $modulesDir)) {
        if ($lang -eq '1') { Write-Msg (Red "  [!] No /modules/ folder found - skipping backup.") }
        else               { Write-Msg (Red "  [!] Kein /modules/-Ordner gefunden - Backup uebersprungen.") }
        return $null
    }

    $pluginName = Split-Path $rootPath -Leaf
    $timestamp  = Get-Date -Format 'yyyyMMdd_HHmmss'
    $backupDir  = Join-Path $PSScriptRoot ('backups\' + $pluginName)
    $zipPath    = Join-Path $backupDir ($pluginName + '_' + $timestamp + '.zip')

    if (-not (Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory($modulesDir, $zipPath)

    Write-Msg ""
    if ($lang -eq '1') {
        Write-Msg ("  " + (Green "[OK] Backup created:"))
    } else {
        Write-Msg ("  " + (Green "[OK] Backup erstellt:"))
    }
    Write-Msg (White "       $zipPath")
    Write-Msg ""
    return $zipPath
}

# ---------------------------------------------------------------------------
# Remove unused modules from /modules/
# Also removes associated .dist-info metadata folders.
# ---------------------------------------------------------------------------
function Remove-UnusedModules {
    param($rootPath, $toRemove, $modulesMap, $lang)

    if ($toRemove.Count -eq 0) { return }

    Write-Msg ""
    Write-Msg (Cyan "  ================================================================")
    Write-Msg (Bold (White "   CLEANUP  --  Remove Unused Modules"))
    Write-Msg (Cyan "  ================================================================")
    Write-Msg ""

    if ($lang -eq '1') {
        $ask = Read-Msg "  Remove $($toRemove.Count) unused module(s) from /modules/? [Y/N]"
        $yes = ($ask -eq 'Y' -or $ask -eq 'y')
    } else {
        $ask = Read-Msg "  $($toRemove.Count) ungenutzte(s) Modul(e) aus /modules/ loeschen? [J/N]"
        $yes = ($ask -eq 'J' -or $ask -eq 'j' -or $ask -eq 'Y' -or $ask -eq 'y')
    }

    if (-not $yes) {
        if ($lang -eq '1') { Write-Msg (Dim "  Cleanup skipped.") }
        else               { Write-Msg (Dim "  Bereinigung uebersprungen.") }
        return
    }

    $modulesDir = Join-Path $rootPath 'modules'

    foreach ($item in $toRemove) {
        $targetPath = $null
        if ($modulesMap.PythonPackages.Contains($item)) { $targetPath = $modulesMap.PythonPackages[$item].Path }
        elseif ($modulesMap.Singles.Contains($item))    { $targetPath = $modulesMap.Singles[$item] }

        if ($targetPath -and (Test-Path $targetPath)) {
            Remove-Item -Path $targetPath -Recurse -Force -ErrorAction SilentlyContinue
            if ($lang -eq '1') { Write-Msg ("  " + (Red "[-]") + " Removed: $item") }
            else               { Write-Msg ("  " + (Red "[-]") + " Geloescht: $item") }
        }

        # Remove associated .dist-info folder if present
        foreach ($dist in $modulesMap.DistInfos.Keys) {
            if ($modulesMap.DistInfos[$dist] -eq $item) {
                $distPath = Join-Path $modulesDir $dist
                if (Test-Path $distPath) {
                    Remove-Item -Path $distPath -Recurse -Force -ErrorAction SilentlyContinue
                    if ($lang -eq '1') { Write-Msg ("  " + (Red "[-]") + " Removed metadata: $dist") }
                    else               { Write-Msg ("  " + (Red "[-]") + " Metadaten geloescht: $dist") }
                }
            }
        }
    }
    Write-Msg ""
}

# ---------------------------------------------------------------------------
# Write plugin-config.txt next to this script.
# Maps module folder names to their real PyPI package names where needed.
# Skips internal, binary-only, and dev-tool entries.
# ---------------------------------------------------------------------------
function Write-Config {
    param($rootPath, $modulesMap)

    $modulesDir = Join-Path $rootPath 'modules'
    $configPath = Join-Path $PSScriptRoot 'plugin-config.txt'
    $timestamp  = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $backupDir  = Join-Path $PSScriptRoot 'backups'
    $cacheDir   = Join-Path $PSScriptRoot 'pip-cache'

    # Entries that must never appear in the LIBRARIES list
    $blacklist = @(
        'galaxy_api','bnet','examples','bin','splash','test','tests','docs','doc',
        'steam_network',
        'pytest','_pytest','py','pluggy','iniconfig','atomicwrites',
        'pip','pip_tools','setuptools','wheel','piptools','pep517',
        'click','colorama','invoke','pyparsing','build','pyproject_hooks',
        '_distutils_hack','importlib_metadata','zipp','tomli',
        'asynctest','mypy_extensions'
    )

    # Maps folder/import names to their installable PyPI package names
    $packageMapping = @{
        'galaxy'   = 'galaxy_plugin_api'
        'google'   = 'protobuf'
        'yaml'     = 'PyYAML'
        'PIL'      = 'Pillow'
        'cv2'      = 'opencv-python'
        'bs4'      = 'beautifulsoup4'
        'sklearn'  = 'scikit-learn'
        'dateutil' = 'python-dateutil'
        'attr'     = 'attrs'
    }

    $libs = New-Object 'System.Collections.Generic.SortedSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)

    foreach ($k in $modulesMap.PythonPackages.Keys) {
        if ($k -notin $blacklist) {
            $mapped = if ($packageMapping.ContainsKey($k)) { $packageMapping[$k] } else { $k }
            [void]$libs.Add($mapped)
        }
    }
    foreach ($v in $modulesMap.DistInfos.Values) {
        if ($v -notin $blacklist) {
            $mapped = if ($packageMapping.ContainsKey($v)) { $packageMapping[$v] } else { $v }
            [void]$libs.Add($mapped)
        }
    }
    foreach ($s in $modulesMap.Singles.Keys) {
        $ext = [System.IO.Path]::GetExtension($modulesMap.Singles[$s])
        if ($ext -eq '.pyd') { continue }
        if (-not ($s -match '^_') -and ($s -notin $blacklist)) {
            $mapped = if ($packageMapping.ContainsKey($s)) { $packageMapping[$s] } else { $s }
            [void]$libs.Add($mapped)
        }
    }

    # Compiled extension files (.pyd) that pip cannot reinstall -- listed separately
    $deleteOnly = New-Object 'System.Collections.Generic.List[string]'
    foreach ($s in $modulesMap.Singles.Keys) {
        $ext = [System.IO.Path]::GetExtension($modulesMap.Singles[$s])
        if ($ext -eq '.pyd') { $deleteOnly.Add($s + $ext) }
    }

    $lines = New-Object 'System.Collections.Generic.List[string]'
    $lines.Add("# ================================================================")
    $lines.Add("# $TOOL_NAME  -  Configuration File")
    $lines.Add("# Generated by $TOOL_NAME $TOOL_VERSION")
    $lines.Add("# $timestamp")
    $lines.Add("# ================================================================")
    $lines.Add("")
    $lines.Add("TOOL_NAME    = $TOOL_NAME")
    $lines.Add("TOOL_VERSION = $TOOL_VERSION")
    $lines.Add("")
    $lines.Add("PLUGIN_DIR     = $modulesDir")
    $lines.Add("PYTHON_VERSION = 3.13")
    $lines.Add("")
    $lines.Add("PIP_CACHE_DIR               = $cacheDir")
    $lines.Add("BACKUP_DIR                  = $backupDir")
    $lines.Add("CLEANUP_CACHE_AFTER_INSTALL = false")
    $lines.Add("KEEP_BACKUP_AFTER_SUCCESS   = true")
    $lines.Add("")

    if ($deleteOnly.Count -gt 0) {
        $lines.Add("DELETE_ONLY =")
        foreach ($d in $deleteOnly) { $lines.Add($d) }
        $lines.Add("")
    }

    $lines.Add("LIBRARIES =")
    foreach ($lib in $libs) {
        if (-not ($lib -match '^_')) { $lines.Add($lib) }
    }

    [System.IO.File]::WriteAllLines($configPath, $lines, (New-Object System.Text.UTF8Encoding $false))
    return $configPath
}

# ---------------------------------------------------------------------------
# Step 4 summary: show config path and backup path
# ---------------------------------------------------------------------------
function Write-Step4Summary {
    param($configPath, $backupPath, $lang)

    if ($lang -eq '1') { $t = 'Summary & next steps' } else { $t = 'Zusammenfassung' }
    Write-StepHeader '4' '4' $t

    if ($lang -eq '1') {
        Write-Msg ("  " + (Green "[OK]") + " plugin-config.txt written:")
    } else {
        Write-Msg ("  " + (Green "[OK]") + " plugin-config.txt geschrieben:")
    }
    Write-Msg (White "       $configPath")

    if ($backupPath) {
        Write-Msg ("  " + (Green "[OK]") + " Backup: " + (White $backupPath))
    }
    Write-Msg ""
}

# ---------------------------------------------------------------------------
# Updater
#
# Reads PLUGIN_DIR and LIBRARIES from plugin-config.txt, finds any available
# Python 3.x (prefers 3.13), and installs each library with pip using
# cross-version wheel targeting:
#   --python-version 3.13  --platform win_amd64  --abi cp313
# This works even when the installed Python is not 3.13.
#
# Fallback chain per library:
#   1. cp313 binary wheel  (--only-binary :all:  with version/platform flags)
#   2. any pure-Python wheel  (--only-binary :all:  without version flags)
#   3. source build  (no binary restriction)
# ---------------------------------------------------------------------------
function Start-Updater {
    param($configPath, $lang)

    Write-Msg ""
    Write-Msg (Cyan "  ================================================================")
    Write-Msg (Bold (White "   UPDATER  --  $TOOL_NAME $TOOL_VERSION"))
    Write-Msg (Cyan "  ================================================================")
    Write-Msg ""

    if ($lang -eq '1') {
        $ask = Read-Msg "  Start Updater? Installs/updates all libs via pip [Y/N]"
        $yes = ($ask -eq 'Y' -or $ask -eq 'y')
    } else {
        $ask = Read-Msg "  Updater starten? Alle Bibliotheken per pip aktualisieren [J/N]"
        $yes = ($ask -eq 'J' -or $ask -eq 'j' -or $ask -eq 'Y' -or $ask -eq 'y')
    }

    if (-not $yes) {
        if ($lang -eq '1') { Write-Msg (Dim "  Updater skipped.") }
        else               { Write-Msg (Dim "  Updater uebersprungen.") }
        return
    }

    if (-not (Test-Path $configPath)) {
        if ($lang -eq '1') { Write-Msg (Red "  [!] plugin-config.txt not found: $configPath") }
        else               { Write-Msg (Red "  [!] plugin-config.txt nicht gefunden: $configPath") }
        return
    }

    # Parse PLUGIN_DIR and LIBRARIES from config
    $cfgLines  = Get-Content $configPath -Encoding UTF8
    $pluginDir = $null
    $libraries = New-Object 'System.Collections.Generic.List[string]'
    $inLibs    = $false

    foreach ($line in $cfgLines) {
        $line = $line.Trim()
        if ($line -match '^#' -or $line -eq '') { $inLibs = $false; continue }
        if ($line -match '^PLUGIN_DIR\s*=\s*(.+)$') { $pluginDir = $Matches[1].Trim(); $inLibs = $false; continue }
        if ($line -eq 'LIBRARIES =') { $inLibs = $true; continue }
        if ($line -match '^[A-Z_]+=') { $inLibs = $false; continue }
        if ($inLibs -and $line -ne '') { $libraries.Add($line) }
    }

    if (-not $pluginDir) {
        if ($lang -eq '1') { Write-Msg (Red "  [!] PLUGIN_DIR not found in config.") }
        else               { Write-Msg (Red "  [!] PLUGIN_DIR nicht in der Config gefunden.") }
        return
    }

    # Locate Python -- prefer 3.13, accept any 3.x
    $py    = $null
    $pyVer = $null

    $candidates313 = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'),
        'C:\Python313\python.exe',
        'C:\Program Files\Python313\python.exe'
    )
    $candidatesAny = @()
    $fromPath = Get-Command python  -ErrorAction SilentlyContinue
    if ($fromPath) { $candidatesAny += $fromPath.Source }
    $from3    = Get-Command python3 -ErrorAction SilentlyContinue
    if ($from3)    { $candidatesAny += $from3.Source }

    $pyBase = Join-Path $env:LOCALAPPDATA 'Programs\Python'
    if (Test-Path $pyBase) {
        Get-ChildItem $pyBase -Filter 'Python3*' -Directory -ErrorAction SilentlyContinue |
            ForEach-Object { $candidatesAny += (Join-Path $_.FullName 'python.exe') }
    }

    foreach ($cand in ($candidates313 + $candidatesAny)) {
        if (-not $cand) { continue }
        if (-not (Test-Path $cand -ErrorAction SilentlyContinue)) { continue }
        $ver = (& $cand --version 2>&1)
        if ($ver -match '(\d+\.\d+)') {
            if (-not $py) { $py = $cand; $pyVer = $Matches[1] }
            if ($ver -match '3\.13') { $py = $cand; $pyVer = '3.13'; break }
        }
    }

    if (-not $py) {
        if ($lang -eq '1') {
            Write-Msg (Red "  [!] No Python installation found.")
            Write-Msg (Dim "      Install any Python 3.x from python.org and retry.")
        } else {
            Write-Msg (Red "  [!] Keine Python-Installation gefunden.")
            Write-Msg (Dim "      Beliebiges Python 3.x von python.org installieren und nochmal versuchen.")
        }
        return
    }

    $crossVersion = ($pyVer -ne '3.13')

    if ($lang -eq '1') {
        Write-Msg ("  " + (Green "[OK] Python found :") + " " + (White "$py  ($pyVer)"))
        if ($crossVersion) {
            Write-Msg ("  " + (Yellow "[i]  Not 3.13 -- pip will target 3.13 wheels via --python-version 3.13"))
        }
    } else {
        Write-Msg ("  " + (Green "[OK] Python gefunden :") + " " + (White "$py  ($pyVer)"))
        if ($crossVersion) {
            Write-Msg ("  " + (Yellow "[i]  Nicht 3.13 -- pip holt 3.13-Wheels via --python-version 3.13"))
        }
    }
    Write-Msg ("  " + (Green "[OK] Target :") + " " + (White $pluginDir))
    Write-Msg ""

    if (-not (Test-Path $pluginDir)) { New-Item -ItemType Directory -Path $pluginDir -Force | Out-Null }

    $cacheDir = Join-Path $PSScriptRoot 'pip-cache'
    if (-not (Test-Path $cacheDir)) { New-Item -ItemType Directory -Path $cacheDir -Force | Out-Null }

    $total   = $libraries.Count
    $i       = 0
    $outFile = Join-Path $env:TEMP 'gps_pip_out.txt'
    $errFile = Join-Path $env:TEMP 'gps_pip_err.txt'

    if ($lang -eq '1') { Write-Msg (Bold "  Installing $total libraries...") }
    else               { Write-Msg (Bold "  Installiere $total Bibliotheken...") }
    Write-Msg ""

    foreach ($lib in $libraries) {
        $i++
        Write-Msg ("  " + (Cyan "[$i/$total]") + " " + (White $lib) + " ...") -NoNewline

        # Attempt 1: cp313 binary wheel with explicit platform targeting
        $pipBase = @(
            '-m','pip','install',
            '--target', "`"$pluginDir`"",
            '--cache-dir', "`"$cacheDir`"",
            '--upgrade',
            '--python-version', '3.13',
            '--platform', 'win_amd64',
            '--implementation', 'cp',
            '--abi', 'cp313',
            '--only-binary', ':all:'
        )
        $proc = Start-Process -FilePath $py -ArgumentList ($pipBase + $lib) `
                    -Wait -PassThru -NoNewWindow `
                    -RedirectStandardOutput $outFile -RedirectStandardError $errFile

        if ($proc.ExitCode -eq 0) {
            Write-Msg (" " + (Green "[OK]"))
        } else {
            # Attempt 2: any pure-Python wheel (no platform/abi constraints)
            $pipPure = @(
                '-m','pip','install',
                '--target', "`"$pluginDir`"",
                '--cache-dir', "`"$cacheDir`"",
                '--upgrade',
                '--only-binary', ':all:'
            )
            $proc2 = Start-Process -FilePath $py -ArgumentList ($pipPure + $lib) `
                         -Wait -PassThru -NoNewWindow `
                         -RedirectStandardOutput $outFile -RedirectStandardError $errFile

            if ($proc2.ExitCode -eq 0) {
                if ($lang -eq '1') { Write-Msg (" " + (Yellow "[OK - pure wheel]")) }
                else               { Write-Msg (" " + (Yellow "[OK - Pure Wheel]")) }
            } else {
                # Attempt 3: allow source build as last resort
                $pipSrc = @(
                    '-m','pip','install',
                    '--target', "`"$pluginDir`"",
                    '--cache-dir', "`"$cacheDir`"",
                    '--upgrade'
                )
                $proc3 = Start-Process -FilePath $py -ArgumentList ($pipSrc + $lib) `
                             -Wait -PassThru -NoNewWindow `
                             -RedirectStandardOutput $outFile -RedirectStandardError $errFile

                if ($proc3.ExitCode -eq 0) {
                    if ($lang -eq '1') { Write-Msg (" " + (Yellow "[OK - source build]")) }
                    else               { Write-Msg (" " + (Yellow "[OK - Source-Build]")) }
                } else {
                    Write-Msg (" " + (Red "[FAILED]"))
                    $errTxt = Get-Content $errFile -ErrorAction SilentlyContinue
                    if ($errTxt) {
                        $short = ($errTxt | Select-Object -Last 3) -join ' | '
                        Write-Msg (Red "         $short")
                    }
                }
            }
        }
    }

    Write-Msg ""
    if ($lang -eq '1') {
        Write-Msg (Bold (Green "  Update complete!"))
        Write-Msg (Dim  "  All libraries installed to: $pluginDir")
    } else {
        Write-Msg (Bold (Green "  Update abgeschlossen!"))
        Write-Msg (Dim  "  Alle Bibliotheken installiert in: $pluginDir")
    }

    # Post-install cleanup: remove orphaned .dist-info folders and known dev-tool leftovers
    Write-Msg ""
    if ($lang -eq '1') {
        Write-Msg (Bold (White "  [*] Post-install cleanup..."))
    } else {
        Write-Msg (Bold (White "  [*] Post-Install Bereinigung..."))
    }

    # Some dist-info names differ from their package folder name
    $distInfoFolderMap = @{
        'galaxy_plugin_api' = 'galaxy'
        'protobuf'          = 'google'
    }

    # Remove .dist-info folders whose matching package folder no longer exists
    $distInfoDirs = Get-ChildItem -Path $pluginDir -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '\.dist-info$' }

    foreach ($di in $distInfoDirs) {
        $pkgName   = ($di.Name -replace '-[^-]+\.dist-info$', '')
        $pkgFolder = if ($distInfoFolderMap.ContainsKey($pkgName)) { $distInfoFolderMap[$pkgName] } else { $pkgName }
        $pkgPath   = Join-Path $pluginDir $pkgFolder
        $pyPath    = Join-Path $pluginDir ($pkgFolder + '.py')
        if (-not (Test-Path $pkgPath) -and -not (Test-Path $pyPath)) {
            Remove-Item -Path $di.FullName -Recurse -Force -ErrorAction SilentlyContinue
            if ($lang -eq '1') { Write-Msg ("  " + (Red "[-]") + " Removed orphaned metadata: $($di.Name)") }
            else               { Write-Msg ("  " + (Red "[-]") + " Verwaiste Metadaten geloescht: $($di.Name)") }
        }
    }

    # Remove known dev-tool single-file leftovers that pip may have dropped.
    # typing_extensions.py and typing_inspect.py are legitimate -- leave them alone.
    # FIX in v1.1.20: Removed 'six.py' from the deletion array because it is a legitimate runtime library
    $devToolFiles = @('zipp.py','py.py','tomli.py')
    foreach ($pyFile in $devToolFiles) {
        $pyPath = Join-Path $pluginDir $pyFile
        if (Test-Path $pyPath) {
            Remove-Item -Path $pyPath -Force -ErrorAction SilentlyContinue
            if ($lang -eq '1') { Write-Msg ("  " + (Red "[-]") + " Removed leftover: $pyFile") }
            else               { Write-Msg ("  " + (Red "[-]") + " Uebriggebliebene Datei geloescht: $pyFile") }
        }
    }
    Write-Msg ""
}

# ===========================================================================
#  MAIN
# ===========================================================================
Show-Banner
if ($DryRun) {
    Write-Host "===============================================" -ForegroundColor Yellow
    Write-Host "              *** DRY-RUN MODE ***" -ForegroundColor Black -BackgroundColor Yellow
    Write-Host "      No files will be modified in this run." -ForegroundColor Yellow
    Write-Host "===============================================" -ForegroundColor Yellow
}
$lang = Select-Language
Show-Greeting -lang $lang
$root = Get-PluginRoot -lang $lang

# Initialize log file in <script dir>/logs/
$pluginName = Split-Path ($root.TrimEnd('\')) -Leaf
$timestamp  = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
$logDir     = Join-Path $PSScriptRoot 'logs'
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
$global:LogFile = Join-Path $logDir "${timestamp}_${pluginName}.log"

Write-Msg "================================================================" -LogOnly
Write-Msg "$TOOL_NAME $TOOL_VERSION - Execution Log" -LogOnly
Write-Msg "Date    : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -LogOnly
Write-Msg "Plugin  : $pluginName" -LogOnly
Write-Msg "Path    : $root" -LogOnly
Write-Msg "Language: $(if($lang -eq '1'){'English'}else{'Deutsch'})" -LogOnly
Write-Msg "================================================================" -LogOnly
Write-Msg "" -LogOnly

# Step 1
if ($lang -eq '1') { $stepTitle = 'Scanning .py files in ROOT...' } else { $stepTitle = 'Scanne .py-Dateien im ROOT...' }
Write-StepHeader '1' '4' $stepTitle
$pyFilesRoot = Get-RootPyFiles -rootPath $root
if ($lang -eq '1') {
    Write-Msg ("  " + (Green "Found") + " " + (White "$($pyFilesRoot.Count)") + " .py file(s) in ROOT.")
} else {
    Write-Msg ("  " + (Green "Gefunden:") + " " + (White "$($pyFilesRoot.Count)") + " .py-Datei(en) im ROOT.")
}

# Step 2
if ($lang -eq '1') { $stepTitle = 'Mapping /modules/ content...' } else { $stepTitle = 'Kartiere /modules/-Inhalte...' }
Write-StepHeader '2' '4' $stepTitle
$modulesMap = Get-ModulesMap -rootPath $root
$totalPy    = $modulesMap.PythonPackages.Count + $modulesMap.Singles.Count
Write-Msg ("  " + (Cyan "Python items") + " : " + (White "$totalPy"))
Write-Msg ("  " + (Cyan "Dist-Infos  ") + " : " + (White "$($modulesMap.DistInfos.Count)"))
Write-Msg ("  " + (Cyan "Non-Python  ") + " : " + (White "$($modulesMap.NonPython.Count)"))

# Step 3
if ($lang -eq '1') { $stepTitle = 'Resolving full dependency tree...' } else { $stepTitle = 'Abhaengigkeitsbaum aufloesen...' }
Write-StepHeader '3' '4' $stepTitle
$pyFilesAll  = Get-AllPyFiles -rootPath $root
$rootImports = Get-Imports -pyFiles $pyFilesRoot -rootPath $root
$allImports  = Get-Imports -pyFiles $pyFilesAll  -rootPath $root
$tree        = Resolve-DependencyTree -rootImports $rootImports -allImports $allImports -modulesMap $modulesMap

Write-Report -rootPath $root -pyFiles $pyFilesRoot -modulesMap $modulesMap -tree $tree -lang $lang

# Dry-run: stop after the report, change nothing
if ($DryRun) {
    Write-Msg ""
    if ($lang -eq '1') {
        Write-Msg (Bold (Yellow "  [DRY-RUN] Simulation complete. No files were changed."))
        Write-Msg (Dim   "  Run without -DryRun to apply changes.")
    } else {
        Write-Msg (Bold (Yellow "  [DRY-RUN] Simulation abgeschlossen. Keine Dateien wurden veraendert."))
        Write-Msg (Dim   "  Ohne -DryRun starten, um Aenderungen anzuwenden.")
    }
    Write-Msg ""
    exit 0
}

# Backup
$backupPath = New-Backup -rootPath $root -lang $lang

# Remove unused modules before writing the config so they are not included
if ($tree.ToRemove.Count -gt 0) {
    Remove-UnusedModules -rootPath $root -toRemove $tree.ToRemove -modulesMap $modulesMap -lang $lang
    # Re-scan so the config reflects the cleaned state
    $modulesMap = Get-ModulesMap -rootPath $root
}

# Config
$configPath = Write-Config -rootPath $root -modulesMap $modulesMap

# Step 4
Write-Step4Summary -configPath $configPath -backupPath $backupPath -lang $lang

# Updater
Start-Updater -configPath $configPath -lang $lang

Write-Msg ""
if ($lang -eq '1') {
    Write-Msg (Bold (Green "  Galaxy Plugin Scout finished. Happy gaming!"))
} else {
    Write-Msg (Bold (Green "  Galaxy Plugin Scout fertig. Viel Spass beim Zocken!"))
}
Write-Msg ""