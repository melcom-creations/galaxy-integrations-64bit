@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul

rem =================================================================
rem  update-plugins.bat  -  melcom Galaxy Plugin Updater v0.1.0
rem  Must stay in the same folder as: update-plugins-helpers.ps1
rem =================================================================

rem ---------------------------------------------------------------
rem  Enable ANSI colors
rem ---------------------------------------------------------------
for /F %%a in ('echo prompt $E^|cmd') do set "ESC=%%a"
set "C_RED=%ESC%[91m"
set "C_GREEN=%ESC%[92m"
set "C_YELLOW=%ESC%[93m"
set "C_CYAN=%ESC%[96m"
set "C_MAGENTA=%ESC%[95m"
set "C_GRAY=%ESC%[90m"
set "C_RESET=%ESC%[0m"
set "C_BOLD=%ESC%[1m"

rem ---------------------------------------------------------------
rem  Paths
rem ---------------------------------------------------------------
set "ROOT=%~dp0"
set "PS1=%ROOT%update-plugins-helpers.ps1"
set "PLUGINS_DIR=%LOCALAPPDATA%\GOG.com\Galaxy\plugins\installed"
set "BACKUP_DIR=%ROOT%backups"
set "LOG_DIR=%ROOT%logs"

if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%" >nul 2>&1
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>&1

for /f %%i in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "TS=%%i"
set "LOGFILE=%LOG_DIR%\update_%TS%.log"
set "SCANFILE=%LOG_DIR%\_scan_%TS%.tmp"
type nul > "%LOGFILE%"

if not exist "%PS1%" (
    echo %C_RED%[ERROR] update-plugins-helpers.ps1 not found next to this batch file.%C_RESET%
    echo %C_RED%[FEHLER] update-plugins-helpers.ps1 wurde nicht neben dieser Batch-Datei gefunden.%C_RESET%
    pause
    exit /b 1
)

rem ---------------------------------------------------------------
rem  Language selection
rem ---------------------------------------------------------------
:LANG_SELECT
cls
echo %C_BOLD%%C_CYAN%============================================================%C_RESET%
echo %C_BOLD%%C_CYAN%  melcom Galaxy Plugin Updater v0.1.0%C_RESET%
echo %C_BOLD%%C_CYAN%============================================================%C_RESET%
echo.
echo  [1] English (US)
echo  [2] Deutsch (DE)
echo.
echo  [x] Exit / Beenden
echo.
set "LANG="
set /p LANGCHOICE=Selection / Auswahl: 
if "%LANGCHOICE%"=="1" set "LANG=EN"
if "%LANGCHOICE%"=="2" set "LANG=DE"
if /i "%LANGCHOICE%"=="X" goto EXIT_NOW
if not defined LANG goto LANG_SELECT
goto LANG_DONE

:EXIT_NOW
echo.
echo Exiting / Beenden ...
if exist "%SCANFILE%" del /q "%SCANFILE%" >nul 2>&1
endlocal
exit /b 0

:LANG_DONE

rem ---------------------------------------------------------------
rem  Text strings per language
rem ---------------------------------------------------------------
if "%LANG%"=="EN" (
    set "MSG_TITLE=melcom Galaxy Plugin Updater v0.1.0"
    set "MSG_SCANNING=Scanning installed plugins ..."
    set "MSG_TABLE_HEAD=Folder / Status / Name"
    set "MSG_VALID=OK (melcom)"
    set "MSG_INVALID=EXCLUDED (not a melcom plugin)"
    set "MSG_NOMANIFEST=EXCLUDED (no manifest.json found)"
    set "MSG_BADJSON=EXCLUDED (manifest.json unreadable)"
    set "MSG_NONE_VALID=No eligible melcom plugins found. Nothing to do."
    set "MSG_CONFIRM_Q=Proceed and check the plugins above marked OK for updates?"
    set "MSG_CONFIRM_YES=[y] Yes, proceed"
    set "MSG_CONFIRM_BACK=[b] Back to language selection"
    set "MSG_CONFIRM_EXIT=[x] Exit"
    set "MSG_CONFIRM_PROMPT=Selection: "
    set "MSG_INVALID_INPUT=Invalid input. Only y, b, or x are allowed."
    set "MSG_ABORTED=Aborted by user. No changes were made."
    set "MSG_CHECKING=Checking for updates ..."
    set "MSG_UPTODATE=Already up to date."
    set "MSG_LOCAL_AHEAD=Locally installed version is newer than the latest published release - nothing to do."
    set "MSG_UPDATE_FOUND=Update available:"
    set "MSG_CHECK_ERROR=Could not check for updates:"
    set "MSG_BACKUP_START=Creating backup ..."
    set "MSG_BACKUP_OK=Backup created:"
    set "MSG_BACKUP_FAIL=Backup FAILED - skipping this plugin for safety:"
    set "MSG_SECRET_BN_WARN=This plugin stores your Battle.net CLIENT_ID and CLIENT_SECRET in consts.py. The update will overwrite this file."
    set "MSG_SECRET_IT_WARN=This plugin stores your itch.io access_token in credentials.json. The update will overwrite this file."
    set "MSG_SECRET_FOUND=Sensitive data found in this file."
    set "MSG_SECRET_BACKUP_ASK=Back up this file now, so it can be offered for restoring right after the update?"
    set "MSG_SECRET_SKIPPED=Backup skipped - you will likely need to re-enter your credentials in this plugin after the update."
    set "MSG_SECRET_NONE=No active token found in this file - nothing sensitive to back up."
    set "MSG_SECRET_BK_OK=Secret file backed up to:"
    set "MSG_SECRET_BK_FAIL=Could not back up the secret file - update of this plugin will be skipped:"
    set "MSG_DOWNLOADING=Downloading and installing update ..."
    set "MSG_UPDATE_OK=Update installed successfully."
    set "MSG_UPDATE_FAIL=Update FAILED. Your backup is still available in the backups folder."
    set "MSG_RESTORE_ASK=Restore the secret file you backed up earlier, so this plugin keeps working with your existing credentials?"
    set "MSG_YN_PROMPT=[Y/N]: "
    set "MSG_RESTORE_OK=Secret file restored."
    set "MSG_RESTORE_FAIL=Could not restore the secret file. Please copy it back manually from:"
    set "MSG_SUMMARY=Summary"
    set "MSG_DONE_UPDATED=updated"
    set "MSG_DONE_SKIPPED=skipped / already up to date"
    set "MSG_DONE_FAILED=failed"
    set "MSG_LOG_SAVED=Log saved to:"
    set "MSG_PRESS_KEY=Press any key to exit ..."
    set "MSG_PLUGINSDIR_MISSING=Plugin folder not found:"
    set "MSG_VERSION_NOTE=Note: version numbers are never changed by this tool - the author decides all version bumps."
) else (
    set "MSG_TITLE=melcom Galaxy Plugin Updater v0.1.0"
    set "MSG_SCANNING=Installierte Plugins werden gescannt ..."
    set "MSG_TABLE_HEAD=Ordner / Status / Name"
    set "MSG_VALID=OK (melcom)"
    set "MSG_INVALID=AUSGESCHLOSSEN (kein melcom-Plugin)"
    set "MSG_NOMANIFEST=AUSGESCHLOSSEN (keine manifest.json gefunden)"
    set "MSG_BADJSON=AUSGESCHLOSSEN (manifest.json nicht lesbar)"
    set "MSG_NONE_VALID=Keine passenden melcom-Plugins gefunden. Nichts zu tun."
    set "MSG_CONFIRM_Q=Oben mit OK markierte Plugins auf Updates pruefen?"
    set "MSG_CONFIRM_YES=[j] Ja, fortfahren"
    set "MSG_CONFIRM_BACK=[b] Zurueck zur Sprachauswahl"
    set "MSG_CONFIRM_EXIT=[x] Beenden"
    set "MSG_CONFIRM_PROMPT=Auswahl: "
    set "MSG_INVALID_INPUT=Ungueltige Eingabe. Nur j, b oder x sind erlaubt."
    set "MSG_ABORTED=Vom Benutzer abgebrochen. Es wurden keine Aenderungen vorgenommen."
    set "MSG_CHECKING=Update wird geprueft ..."
    set "MSG_UPTODATE=Bereits aktuell."
    set "MSG_LOCAL_AHEAD=Lokal installierte Version ist neuer als die aktuellste veroeffentlichte Version - nichts zu tun."
    set "MSG_UPDATE_FOUND=Update verfuegbar:"
    set "MSG_CHECK_ERROR=Update-Pruefung fehlgeschlagen:"
    set "MSG_BACKUP_START=Sicherung wird erstellt ..."
    set "MSG_BACKUP_OK=Sicherung erstellt:"
    set "MSG_BACKUP_FAIL=Sicherung FEHLGESCHLAGEN - Plugin wird zur Sicherheit uebersprungen:"
    set "MSG_SECRET_BN_WARN=Dieses Plugin speichert deine Battle.net CLIENT_ID und CLIENT_SECRET in consts.py. Das Update ueberschreibt diese Datei."
    set "MSG_SECRET_IT_WARN=Dieses Plugin speichert dein itch.io access_token in credentials.json. Das Update ueberschreibt diese Datei."
    set "MSG_SECRET_FOUND=Sensible Daten in dieser Datei gefunden."
    set "MSG_SECRET_BACKUP_ASK=Diese Datei jetzt sichern, damit sie dir direkt nach dem Update zum Zuruecklegen angeboten werden kann?"
    set "MSG_SECRET_SKIPPED=Sicherung uebersprungen - du musst deine Zugangsdaten in diesem Plugin nach dem Update vermutlich neu eingeben."
    set "MSG_SECRET_NONE=Kein aktives Token in dieser Datei gefunden - nichts Sensibles zu sichern."
    set "MSG_SECRET_BK_OK=Sicherheitskopie der Datei erstellt:"
    set "MSG_SECRET_BK_FAIL=Sicherung der sensiblen Datei fehlgeschlagen - Update dieses Plugins wird uebersprungen:"
    set "MSG_DOWNLOADING=Update wird heruntergeladen und installiert ..."
    set "MSG_UPDATE_OK=Update erfolgreich installiert."
    set "MSG_UPDATE_FAIL=Update FEHLGESCHLAGEN. Die Sicherung liegt weiterhin im backups-Ordner."
    set "MSG_RESTORE_ASK=Die vorhin gesicherte Datei zurueckspielen, damit dieses Plugin mit deinen bestehenden Zugangsdaten weiterlaeuft?"
    set "MSG_YN_PROMPT=[J/N]: "
    set "MSG_RESTORE_OK=Datei wurde zurueckgespielt."
    set "MSG_RESTORE_FAIL=Datei konnte nicht zurueckgespielt werden. Bitte manuell kopieren von:"
    set "MSG_SUMMARY=Zusammenfassung"
    set "MSG_DONE_UPDATED=aktualisiert"
    set "MSG_DONE_SKIPPED=uebersprungen / bereits aktuell"
    set "MSG_DONE_FAILED=fehlgeschlagen"
    set "MSG_LOG_SAVED=Log gespeichert unter:"
    set "MSG_PRESS_KEY=Beliebige Taste zum Beenden druecken ..."
    set "MSG_PLUGINSDIR_MISSING=Plugin-Ordner nicht gefunden:"
    set "MSG_VERSION_NOTE=Hinweis: Versionsnummern werden von diesem Tool nie veraendert - allein der Autor entscheidet ueber Versionserhoehungen."
)

cls
call :SAY "%C_BOLD%%C_CYAN%" "===================================================================="
call :SAY "%C_BOLD%%C_CYAN%" " %MSG_TITLE%"
call :SAY "%C_BOLD%%C_CYAN%" "===================================================================="
call :SAY "%C_GRAY%" "%MSG_VERSION_NOTE%"
call :SAY "" ""

if not exist "%PLUGINS_DIR%" (
    call :SAY "%C_RED%" "%MSG_PLUGINSDIR_MISSING% %PLUGINS_DIR%"
    goto FINISH
)

rem ---------------------------------------------------------------
rem  Scan
rem ---------------------------------------------------------------
rem  Discovers plugin folders and checks manifest.json trust
call :SAY "%C_CYAN%" "%MSG_SCANNING%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Action ScanPlugins -PluginsDir "%PLUGINS_DIR%" > "%SCANFILE%"

set /a N=0
for /f "usebackq tokens=1-9 delims=|" %%a in ("%SCANFILE%") do (
    set /a N+=1
    set "DIRNAME[!N!]=%%a"
    set "VALID[!N!]=%%b"
    set "PNAME[!N!]=%%c"
    set "PLATFORM[!N!]=%%d"
    set "PGUID[!N!]=%%e"
    set "PVERSION[!N!]=%%f"
    set "PREPO[!N!]=%%g"
    set "PAPI[!N!]=%%h"
    set "PPATTERN[!N!]=%%i"
)

if !N! equ 0 (
    call :SAY "" ""
    call :SAY "%C_YELLOW%" "%MSG_NONE_VALID%"
    goto FINISH
)

set /a ANYVALID=0
for /l %%i in (1,1,!N!) do (
    if "!VALID[%%i]!"=="1" set /a ANYVALID+=1
)

if !ANYVALID! equ 0 (
    call :DRAW_TABLE SAY
    call :SAY "%C_YELLOW%" "%MSG_NONE_VALID%"
    goto FINISH
)

:CONFIRM_PROMPT
rem  First draw: goes to console AND log (call :SAY), so the log keeps
rem  one authoritative record of what was shown and asked.
call :DRAW_TABLE SAY
call :DRAW_MENU SAY
goto CONFIRM_INPUT

:CONFIRM_REDRAW
rem  Redraw after invalid input: console only (call :ECHO2), so a user
rem  mistyping several times doesn't spam the log with duplicate copies
rem  of the same screen. The screen is always cleared and redrawn in
rem  full, so the plugin list never scrolls out of view. The invalid-
rem  input notice is printed as the LAST thing before the prompt, so
rem  it stays visible right above the input line instead of flashing
rem  by and being wiped by the next cls.
call :DRAW_TABLE ECHO2
call :DRAW_MENU ECHO2
call :ECHO2 "%C_YELLOW%" "%MSG_INVALID_INPUT%"
call :ECHO2 "" ""
goto CONFIRM_INPUT

:CONFIRM_INPUT
set "CONFIRM="
set /p CONFIRM=%MSG_CONFIRM_PROMPT%
if /i "%CONFIRM%"=="Y" goto CONFIRM_PROCEED
if /i "%CONFIRM%"=="J" goto CONFIRM_PROCEED
if /i "%CONFIRM%"=="B" goto LANG_SELECT
if /i "%CONFIRM%"=="X" goto CONFIRM_EXIT
if /i "%CONFIRM%"=="N" goto CONFIRM_EXIT
goto CONFIRM_REDRAW

:CONFIRM_EXIT
call :SAY "%C_YELLOW%" "%MSG_ABORTED%"
set "SKIP_LOG=1"
goto FINISH

:CONFIRM_PROCEED
call :SAY "" ""

set /a CNT_UPDATED=0
set /a CNT_SKIPPED=0
set /a CNT_FAILED=0

rem ---------------------------------------------------------------
rem  Update loop
rem ---------------------------------------------------------------
for /l %%i in (1,1,!N!) do (
    if "!VALID[%%i]!"=="1" (
        call :ProcessPlugin "%%i"
    )
)

goto SUMMARY

rem ===================================================================
:ProcessPlugin
setlocal EnableDelayedExpansion
set "IDX=%~1"
set "DN=!DIRNAME[%IDX%]!"
set "PN=!PNAME[%IDX%]!"
set "RP=!PREPO[%IDX%]!"
set "API=!PAPI[%IDX%]!"
set "PAT=!PPATTERN[%IDX%]!"
set "LV=!PVERSION[%IDX%]!"

call :SAY "" ""
call :SAY "%C_BOLD%%C_CYAN%" "----------------------------------------------------------------"
call :SAY "%C_BOLD%" "  !PN!"
call :SAY "%C_GRAY%" "  !DN!"
call :SAY "%C_BOLD%%C_CYAN%" "----------------------------------------------------------------"

call :SAY "%C_CYAN%" "  %MSG_CHECKING%"

rem A short pause before each GitHub API request. Without it, checking several
rem plugins right after each other can trip GitHub's secondary (short-term)
rem abuse rate limit even though the plain hourly limit is nowhere near used up.
ping -n 2 127.0.0.1 >nul

set "RESULT="
for /f "usebackq delims=" %%R in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Action CheckUpdate -Repo "!RP!" -LatestApi "!API!" -AssetPattern "!PAT!" -LocalVersion "!LV!"`) do set "RESULT=%%R"

for /f "tokens=1-3 delims=|" %%a in ("!RESULT!") do (
    set "U_STATUS=%%a"
    set "U_TAG=%%b"
    set "U_URL=%%c"
)

if "!U_STATUS!"=="ERROR" (
    call :SAY "%C_RED%" "  %MSG_CHECK_ERROR% !U_TAG!"
    endlocal & set /a CNT_FAILED+=1 & goto :eof
)
if "!U_STATUS!"=="UPTODATE" (
    call :SAY "%C_GREEN%" "  %MSG_UPTODATE% (!U_TAG!)"
    endlocal & set /a CNT_SKIPPED+=1 & goto :eof
)
if "!U_STATUS!"=="AHEAD" (
    call :SAY "%C_GRAY%" "  %MSG_LOCAL_AHEAD% (!U_TAG!)"
    endlocal & set /a CNT_SKIPPED+=1 & goto :eof
)

call :SAY "%C_YELLOW%" "  %MSG_UPDATE_FOUND% !U_TAG!"

rem --- Back up the complete plugin folder ---
call :SAY "%C_CYAN%" "  %MSG_BACKUP_START%"
set "BRESULT="
for /f "usebackq delims=" %%R in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Action BackupPlugin -PluginsDir "%PLUGINS_DIR%" -BackupDir "%BACKUP_DIR%" -PluginDirName "!DN!"`) do set "BRESULT=%%R"
for /f "tokens=1,2 delims=|" %%a in ("!BRESULT!") do (set "B_STATUS=%%a" & set "B_PATH=%%b")

if not "!B_STATUS!"=="OK" (
    call :SAY "%C_RED%" "  %MSG_BACKUP_FAIL% !B_PATH!"
    endlocal & set /a CNT_FAILED+=1 & goto :eof
)
call :SAY "%C_GREEN%" "  %MSG_BACKUP_OK% !B_PATH!"

rem --- Special handling for known secret files ---
set "SECRET_TYPE="
set "SECRET_FILE="
if /i "!DN!"=="battlenet_ba170431-0649-482f-863b-d248592f1842" (
    set "SECRET_TYPE=battlenet"
    set "SECRET_FILE=consts.py"
)
if /i "!DN!"=="itch_2df02142-4d8a-4a4b-9b6e-c3a0bc62f93b" (
    set "SECRET_TYPE=itch"
    set "SECRET_FILE=credentials.json"
)

set "SECRET_BACKUP_PATH="
if defined SECRET_TYPE (
    if "!SECRET_TYPE!"=="battlenet" call :SAY "%C_MAGENTA%" "    %MSG_SECRET_BN_WARN%"
    if "!SECRET_TYPE!"=="itch"      call :SAY "%C_MAGENTA%" "    %MSG_SECRET_IT_WARN%"

    set "CRESULT="
    for /f "usebackq delims=" %%R in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Action CheckSecret -PluginsDir "%PLUGINS_DIR%" -PluginDirName "!DN!" -SecretFile "!SECRET_FILE!" -SecretType "!SECRET_TYPE!"`) do set "CRESULT=%%R"
    for /f "tokens=1,2 delims=|" %%a in ("!CRESULT!") do (set "C_STATUS=%%a" & set "C_PATH=%%b")

    if "!C_STATUS!"=="PRESENT" (
        call :SAY "%C_YELLOW%" "    %MSG_SECRET_FOUND%"
        call :SAY "%C_MAGENTA%" "    %MSG_SECRET_BACKUP_ASK%"
        set "SECRET_CONFIRM="
        set /p SECRET_CONFIRM=%MSG_YN_PROMPT%
        if /i "!SECRET_CONFIRM!"=="Y" set "SECRET_CONFIRM=J"
        if /i "!SECRET_CONFIRM!"=="J" (
            set "SRESULT="
            for /f "usebackq delims=" %%R in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Action BackupSecret -PluginsDir "%PLUGINS_DIR%" -BackupDir "%BACKUP_DIR%" -PluginDirName "!DN!" -SecretFile "!SECRET_FILE!"`) do set "SRESULT=%%R"
            for /f "tokens=1,2 delims=|" %%a in ("!SRESULT!") do (set "S_STATUS=%%a" & set "S_PATH=%%b")

            if "!S_STATUS!"=="OK" (
                call :SAY "%C_GREEN%" "    %MSG_SECRET_BK_OK% !S_PATH!"
                set "SECRET_BACKUP_PATH=!S_PATH!"
            ) else (
                call :SAY "%C_RED%" "    %MSG_SECRET_BK_FAIL% !S_PATH!"
                endlocal & set /a CNT_FAILED+=1 & goto :eof
            )
        ) else (
            call :SAY "%C_YELLOW%" "    %MSG_SECRET_SKIPPED%"
        )
    ) else (
        call :SAY "%C_GRAY%" "    %MSG_SECRET_NONE%"
    )
)

rem --- Download and install the update ---
call :SAY "%C_CYAN%" "  %MSG_DOWNLOADING%"
set "URESULT="
for /f "usebackq delims=" %%R in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Action DoUpdate -PluginsDir "%PLUGINS_DIR%" -PluginDirName "!DN!" -DownloadUrl "!U_URL!"`) do set "URESULT=%%R"
for /f "tokens=1,2 delims=|" %%a in ("!URESULT!") do (set "UP_STATUS=%%a" & set "UP_PATH=%%b")

if not "!UP_STATUS!"=="OK" (
    call :SAY "%C_RED%" "  %MSG_UPDATE_FAIL%"
    endlocal & set /a CNT_FAILED+=1 & goto :eof
)
call :SAY "%C_GREEN%" "  %MSG_UPDATE_OK%"

rem --- Restore the secret file if requested ---
if defined SECRET_BACKUP_PATH (
    call :SAY "%C_MAGENTA%" "    %MSG_RESTORE_ASK%"
    set "RESTORE="
    set /p RESTORE=%MSG_YN_PROMPT%
    if /i "!RESTORE!"=="Y" set "RESTORE=J"
    if /i "!RESTORE!"=="J" (
        set "RRESULT="
        for /f "usebackq delims=" %%R in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Action RestoreSecret -PluginsDir "%PLUGINS_DIR%" -PluginDirName "!DN!" -SecretFile "!SECRET_BACKUP_PATH!" -TargetFile "!SECRET_FILE!"`) do set "RRESULT=%%R"
        for /f "tokens=1,2 delims=|" %%a in ("!RRESULT!") do (set "R_STATUS=%%a" & set "R_PATH=%%b")
        if "!R_STATUS!"=="OK" (
            call :SAY "%C_GREEN%" "    %MSG_RESTORE_OK%"
        ) else (
            call :SAY "%C_RED%" "    %MSG_RESTORE_FAIL% !SECRET_BACKUP_PATH!"
        )
    )
)

call :SAY "" ""
endlocal & set /a CNT_UPDATED+=1 & goto :eof

rem ===================================================================
:SUMMARY
call :SAY "%C_BOLD%%C_CYAN%" "===================================================================="
call :SAY "%C_BOLD%%C_CYAN%" " %MSG_SUMMARY%"
call :SAY "%C_BOLD%%C_CYAN%" "===================================================================="
call :SAY "%C_GREEN%" "  !CNT_UPDATED! %MSG_DONE_UPDATED%"
call :SAY "%C_YELLOW%" "  !CNT_SKIPPED! %MSG_DONE_SKIPPED%"
call :SAY "%C_RED%" "  !CNT_FAILED! %MSG_DONE_FAILED%"
call :SAY "" ""

:FINISH
if defined SKIP_LOG (
    if exist "%LOGFILE%" del /q "%LOGFILE%" >nul 2>&1
) else (
    call :SAY "%C_GRAY%" "%MSG_LOG_SAVED% %LOGFILE%"
)
if exist "%SCANFILE%" del /q "%SCANFILE%" >nul 2>&1
echo.
echo %MSG_PRESS_KEY%
pause >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Action MatrixExit -Lang "%LANG%"
endlocal
exit /b 0

rem ===================================================================
rem  :SAY <colorcode> <message>  -  prints colored to console, plain to log
rem ===================================================================
:SAY
echo(%~1%~2%C_RESET%
>>"%LOGFILE%" echo(%~2
goto :eof

rem ===================================================================
rem  :ECHO2 <colorcode> <message>  -  same as :SAY but console only,
rem  does not write to the log file. Used to redraw the screen after
rem  an invalid input without piling up duplicate lines in the log.
rem ===================================================================
:ECHO2
echo(%~1%~2%C_RESET%
goto :eof

rem ===================================================================
rem  :DRAW_TABLE <printroutine>  -  clears the screen and draws the
rem  title plus the full plugin table, using either :SAY (console+log)
rem  or :ECHO2 (console only) as the print routine.
rem ===================================================================
:DRAW_TABLE
cls
call :%~1 "%C_BOLD%%C_CYAN%" "===================================================================="
call :%~1 "%C_BOLD%%C_CYAN%" " %MSG_TITLE%"
call :%~1 "%C_BOLD%%C_CYAN%" "===================================================================="
call :%~1 "%C_GRAY%" "%MSG_VERSION_NOTE%"
call :%~1 "" ""
call :%~1 "%C_BOLD%" "%MSG_TABLE_HEAD%"
call :%~1 "%C_GRAY%" "--------------------------------------------------------------------"
for /l %%i in (1,1,!N!) do (
    if "!VALID[%%i]!"=="1" (
        call :%~1 "%C_GREEN%" "  [OK]        !DIRNAME[%%i]!  -  !PNAME[%%i]!"
    ) else (
        if "!PNAME[%%i]!"=="NOMANIFEST" (
            call :%~1 "%C_RED%" "  [EXCLUDED]  !DIRNAME[%%i]!  -  %MSG_NOMANIFEST%"
        ) else if "!PNAME[%%i]!"=="BADJSON" (
            call :%~1 "%C_RED%" "  [EXCLUDED]  !DIRNAME[%%i]!  -  %MSG_BADJSON%"
        ) else (
            call :%~1 "%C_RED%" "  [EXCLUDED]  !DIRNAME[%%i]!  -  !PNAME[%%i]!  -  %MSG_INVALID%"
        )
    )
)
call :%~1 "" ""
goto :eof

rem ===================================================================
rem  :DRAW_MENU <printroutine>  -  draws the update confirmation
rem  question and its three options. Kept separate from :DRAW_TABLE so
rem  the "no eligible plugins" case can show the table without also
rem  showing a menu that would not apply.
rem ===================================================================
:DRAW_MENU
call :%~1 "%C_BOLD%" "%MSG_CONFIRM_Q%"
call :%~1 "" "  %MSG_CONFIRM_YES%"
call :%~1 "" "  %MSG_CONFIRM_BACK%"
call :%~1 "" ""
call :%~1 "" "  %MSG_CONFIRM_EXIT%"
call :%~1 "" ""
goto :eof
