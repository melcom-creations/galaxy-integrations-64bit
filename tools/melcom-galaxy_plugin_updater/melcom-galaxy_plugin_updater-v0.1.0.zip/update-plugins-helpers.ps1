<#
    update-plugins-helpers.ps1
    ---------------------------------------------------------------
    Helper engine for update-plugins.bat.
    This script does NOT run on its own - it is called by the batch
    file for single actions and always prints ONE pipe-delimited
    result line to stdout, which the batch file then parses.

    Must stay in the SAME folder as update-plugins.bat.
    ---------------------------------------------------------------
#>

param(
    [Parameter(Mandatory = $true)][string]$Action,
    [string]$PluginsDir,
    [string]$BackupDir,
    [string]$PluginDirName,
    [string]$Repo,
    [string]$LatestApi,
    [string]$AssetPattern,
    [string]$LocalVersion,
    [string]$DownloadUrl,
    [string]$SecretFile,
    [string]$SecretType,
    [string]$TargetFile,
    [string]$Lang
)

$ErrorActionPreference = "Stop"
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

function Get-Timestamp { Get-Date -Format "yyyyMMdd_HHmmss" }

function Clean([string]$s) {
    if ($null -eq $s) { return "" }
    return ($s -replace '[\|\r\n]', ' ')
}

# Compares two version strings numerically, segment by segment
# (e.g. "2.0.10" vs "2.0.9" -> 2.0.10 is newer, unlike a plain string
# compare). Returns 1 if $a is newer, -1 if $a is older, 0 if equal,
# or $null if either string contains no digits at all and cannot be
# compared reliably.
function Compare-VersionStrings([string]$a, [string]$b) {
    $partsA = [regex]::Matches($a, '\d+') | ForEach-Object { [int]$_.Value }
    $partsB = [regex]::Matches($b, '\d+') | ForEach-Object { [int]$_.Value }
    if ($partsA.Count -eq 0 -or $partsB.Count -eq 0) { return $null }

    $len = [Math]::Max($partsA.Count, $partsB.Count)
    for ($i = 0; $i -lt $len; $i++) {
        $x = if ($i -lt $partsA.Count) { $partsA[$i] } else { 0 }
        $y = if ($i -lt $partsB.Count) { $partsB[$i] } else { 0 }
        if ($x -gt $y) { return 1 }
        if ($x -lt $y) { return -1 }
    }
    return 0
}

switch ($Action) {

    # ---------------------------------------------------------
    # Scans PluginsDir for subfolders that contain a manifest.json
    # and reports whether they belong to the melcom collection.
    # Output per line:
    # DirName|Valid|Name|Platform|Guid|Version|Repo|LatestApi|AssetPattern
    # ---------------------------------------------------------
    "ScanPlugins" {
        if (-not (Test-Path -LiteralPath $PluginsDir)) {
            Write-Output "ERROR|PLUGINSDIR_NOT_FOUND"
            break
        }
        $dirs = Get-ChildItem -LiteralPath $PluginsDir -Directory -ErrorAction SilentlyContinue
        foreach ($d in $dirs) {
            $manifestPath = Join-Path $d.FullName "manifest.json"
            if (-not (Test-Path -LiteralPath $manifestPath)) {
                Write-Output "$($d.Name)|0|NOMANIFEST||||||"
                continue
            }
            try {
                $raw = Get-Content -Raw -LiteralPath $manifestPath -Encoding UTF8
                $m = $raw | ConvertFrom-Json
            } catch {
                Write-Output "$($d.Name)|0|BADJSON||||||"
                continue
            }

            $author = "$($m.author)"
            $url    = "$($m.url)"
            $valid  = 0
            if ($author -match "(?i)melcom" -and $url -match [regex]::Escape("https://github.com/melcom-creations")) {
                $valid = 1
            }

            $repo = ""; $api = ""; $pattern = ""
            if ($m.external_updater) {
                $repo    = "$($m.external_updater.repo)"
                $api     = "$($m.external_updater.latest_release_api)"
                $pattern = "$($m.external_updater.asset_pattern)"
            }

            $name     = Clean "$($m.name)"
            $platform = Clean "$($m.platform)"
            $guid     = Clean "$($m.guid)"
            $version  = Clean "$($m.version)"

            Write-Output "$($d.Name)|$valid|$name|$platform|$guid|$version|$repo|$api|$pattern"
        }
    }

    # ---------------------------------------------------------
    # Asks the GitHub API for the latest release and compares it
    # against the locally installed version string.
    # Output: UPDATE|tag|downloadUrl  /  UPTODATE|tag|downloadUrl  /  ERROR|message
    # ---------------------------------------------------------
    "CheckUpdate" {
        try {
            $headers = @{ "User-Agent" = "melcom-galaxy-updater"; "Accept" = "application/vnd.github+json" }
            # Optional: if a GitHub token is available as an environment variable,
            # use it. Authenticated requests get 5000 requests/hour instead of the
            # 60/hour that apply to anonymous requests, which avoids the rate-limit
            # errors that anonymous checks of several repos in a row can run into.
            if ($env:GITHUB_TOKEN) {
                $headers["Authorization"] = "Bearer $($env:GITHUB_TOKEN)"
            }
            $rel = $null
            try {
                $rel = Invoke-RestMethod -Uri $LatestApi -Headers $headers -Method Get
            } catch {
                $statusCode = $null
                $respHeaders = $null
                if ($_.Exception.Response) {
                    try { $statusCode = [int]$_.Exception.Response.StatusCode } catch {}
                    try { $respHeaders = $_.Exception.Response.Headers } catch {}
                }
                if ($statusCode -eq 404 -or $_.Exception.Message -match '404') {
                    # /releases/latest only ever returns a non-prerelease, non-draft
                    # release. If the repo currently has nothing but a pre-release,
                    # GitHub answers 404 here even though a usable release exists.
                    # Fall back to the full release list and take the newest entry.
                    $listUrl = "https://api.github.com/repos/$Repo/releases"
                    $list = Invoke-RestMethod -Uri $listUrl -Headers $headers -Method Get
                    if ($list -and $list.Count -gt 0) {
                        $rel = $list | Select-Object -First 1
                    } else {
                        Write-Output "ERROR|NO_RELEASES_FOUND"
                        break
                    }
                } elseif ($statusCode -eq 403) {
                    # A 403 from the GitHub API is almost always either the hourly
                    # rate limit (60 requests/hour without a token) or the shorter
                    # secondary/abuse limit (many requests in quick succession).
                    # Both look identical to the user without extra detail, so read
                    # the rate-limit headers GitHub sends along with the 403 and put
                    # them into the error message instead of just "(403) Forbidden".
                    $remaining = $null
                    $resetAt   = $null
                    if ($respHeaders) {
                        try {
                            if ($respHeaders["X-RateLimit-Remaining"]) { $remaining = $respHeaders["X-RateLimit-Remaining"][0] }
                            if ($respHeaders["X-RateLimit-Reset"]) {
                                $resetEpoch = [long]$respHeaders["X-RateLimit-Reset"][0]
                                $resetAt = ([DateTimeOffset]::FromUnixTimeSeconds($resetEpoch)).ToLocalTime().ToString("HH:mm:ss")
                            }
                        } catch {}
                    }
                    if ($remaining -eq "0" -and $resetAt) {
                        Write-Output "ERROR|RATE_LIMIT_EXCEEDED (resets $resetAt, add a GITHUB_TOKEN environment variable to raise the limit)"
                    } elseif ($remaining -or $resetAt) {
                        Write-Output "ERROR|HTTP_403_FORBIDDEN (rate-limit-remaining=$remaining, resets $resetAt)"
                    } else {
                        Write-Output "ERROR|HTTP_403_FORBIDDEN (likely rate limit or abuse detection - see README)"
                    }
                    break
                } else {
                    throw
                }
            }
            $tag = "$($rel.tag_name)"

            $asset = $rel.assets | Where-Object { $_.name -like $AssetPattern } | Select-Object -First 1
            if (-not $asset) {
                Write-Output "ERROR|NO_MATCHING_ASSET_$AssetPattern"
                break
            }

            $tagClean   = ($tag -replace '-64bit$', '') -replace '^[vV]', ''
            $localClean = ($LocalVersion -replace '-64bit$', '') -replace '^[vV]', ''

            $cmp = Compare-VersionStrings $tagClean $localClean
            if ($null -eq $cmp) {
                # Could not parse numeric version segments from one of the
                # two strings - fall back to the old equality-only check
                # rather than guessing a direction.
                if ($tagClean -eq $localClean) {
                    Write-Output "UPTODATE|$tag|$($asset.browser_download_url)"
                } else {
                    Write-Output "UPDATE|$tag|$($asset.browser_download_url)"
                }
            } elseif ($cmp -eq 0) {
                Write-Output "UPTODATE|$tag|$($asset.browser_download_url)"
            } elseif ($cmp -gt 0) {
                Write-Output "UPDATE|$tag|$($asset.browser_download_url)"
            } else {
                # The published release is OLDER than what's installed
                # locally (e.g. an in-development build ahead of the last
                # release) - never overwrite it with something older.
                Write-Output "AHEAD|$tag|$($asset.browser_download_url)"
            }
        } catch {
            Write-Output "ERROR|$(Clean $_.Exception.Message)"
        }
    }

    # ---------------------------------------------------------
    # Zips the complete plugin folder into backups\<dir>\<dir>_TIMESTAMP.zip
    # ---------------------------------------------------------
    "BackupPlugin" {
        try {
            $src = Join-Path $PluginsDir $PluginDirName
            $destDir = Join-Path $BackupDir $PluginDirName
            if (-not (Test-Path -LiteralPath $destDir)) { New-Item -ItemType Directory -Path $destDir | Out-Null }
            $ts = Get-Timestamp
            $zipPath = Join-Path $destDir "$($PluginDirName)_$ts.zip"
            Compress-Archive -Path (Join-Path $src "*") -DestinationPath $zipPath -Force
            Write-Output "OK|$zipPath"
        } catch {
            Write-Output "ERROR|$(Clean $_.Exception.Message)"
        }
    }

    # ---------------------------------------------------------
    # Checks whether a secret file (consts.py / credentials.json)
    # actually contains a usable, non-empty token.
    # Output: PRESENT|path  /  EMPTY|path  /  NOFILE|  /  ERROR|message
    # ---------------------------------------------------------
    "CheckSecret" {
        $filePath = Join-Path (Join-Path $PluginsDir $PluginDirName) $SecretFile
        if (-not (Test-Path -LiteralPath $filePath)) {
            Write-Output "NOFILE|"
            break
        }
        try {
            if ($SecretType -eq "battlenet") {
                $content  = Get-Content -Raw -LiteralPath $filePath -Encoding UTF8
                $idMatch  = [regex]::Match($content, 'CLIENT_ID\s*=\s*"([^"]*)"')
                $secMatch = [regex]::Match($content, 'CLIENT_SECRET\s*=\s*"([^"]*)"')
                $idVal  = if ($idMatch.Success)  { $idMatch.Groups[1].Value.Trim() }  else { "" }
                $secVal = if ($secMatch.Success) { $secMatch.Groups[1].Value.Trim() } else { "" }
                if ($idVal -ne "" -and $secVal -ne "") {
                    Write-Output "PRESENT|$filePath"
                } else {
                    Write-Output "EMPTY|$filePath"
                }
            } elseif ($SecretType -eq "itch") {
                $j   = Get-Content -Raw -LiteralPath $filePath -Encoding UTF8 | ConvertFrom-Json
                $tok = "$($j.access_token)".Trim()
                if ($tok -ne "") {
                    Write-Output "PRESENT|$filePath"
                } else {
                    Write-Output "EMPTY|$filePath"
                }
            } else {
                Write-Output "ERROR|UNKNOWN_SECRET_TYPE"
            }
        } catch {
            Write-Output "EMPTY|$filePath"
        }
    }

    # ---------------------------------------------------------
    # Copies the secret file into the plugin's backup folder
    # (plain copy, timestamped filename - deliberately NOT zipped
    # so it can be restored with a single click).
    # ---------------------------------------------------------
    "BackupSecret" {
        try {
            $filePath = Join-Path (Join-Path $PluginsDir $PluginDirName) $SecretFile
            $destDir  = Join-Path $BackupDir $PluginDirName
            if (-not (Test-Path -LiteralPath $destDir)) { New-Item -ItemType Directory -Path $destDir | Out-Null }
            $ts   = Get-Timestamp
            $leaf = Split-Path $SecretFile -Leaf
            $dest = Join-Path $destDir "$($leaf)_$ts"
            Copy-Item -LiteralPath $filePath -Destination $dest -Force
            Write-Output "OK|$dest"
        } catch {
            Write-Output "ERROR|$(Clean $_.Exception.Message)"
        }
    }

    # ---------------------------------------------------------
    # Restores a previously backed-up secret file back into the
    # plugin folder. SecretFile = full path to the backup copy,
    # TargetFile = relative filename inside the plugin folder.
    # ---------------------------------------------------------
    "RestoreSecret" {
        try {
            $target = Join-Path (Join-Path $PluginsDir $PluginDirName) $TargetFile
            Copy-Item -LiteralPath $SecretFile -Destination $target -Force
            Write-Output "OK|$target"
        } catch {
            Write-Output "ERROR|$(Clean $_.Exception.Message)"
        }
    }

    # ---------------------------------------------------------
    # Downloads the release asset and replaces the plugin folder
    # content with the extracted files.
    # ---------------------------------------------------------
    "DoUpdate" {
        $pluginDir = Join-Path $PluginsDir $PluginDirName
        $tempDir   = Join-Path $env:TEMP ("galaxy_update_" + [guid]::NewGuid().ToString("N"))
        $tempZip   = Join-Path $env:TEMP ("galaxy_update_" + [guid]::NewGuid().ToString("N") + ".zip")
        try {
            Invoke-WebRequest -Uri $DownloadUrl -OutFile $tempZip -Headers @{ "User-Agent" = "melcom-galaxy-updater" }
            New-Item -ItemType Directory -Path $tempDir | Out-Null
            Expand-Archive -LiteralPath $tempZip -DestinationPath $tempDir -Force

            $items = Get-ChildItem -LiteralPath $tempDir
            $sourceRoot = $tempDir
            if ($items.Count -eq 1 -and $items[0].PSIsContainer) {
                $sourceRoot = $items[0].FullName
            }

            Get-ChildItem -LiteralPath $pluginDir -Force | Remove-Item -Recurse -Force
            Copy-Item -Path (Join-Path $sourceRoot "*") -Destination $pluginDir -Recurse -Force

            Write-Output "OK|$pluginDir"
        } catch {
            Write-Output "ERROR|$(Clean $_.Exception.Message)"
        } finally {
            if (Test-Path -LiteralPath $tempZip) { Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue }
            if (Test-Path -LiteralPath $tempDir) { Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue }
        }
    }

    # ---------------------------------------------------------
    # Matrix-style farewell animation shown when the tool finishes.
    # Ported from GalaxyPluginScout's Show-MatrixExit. Purely cosmetic -
    # writes directly to the console and never returns a pipe-delimited
    # result line like the other actions, since there is nothing for
    # the batch file to parse afterwards.
    # ---------------------------------------------------------
    "MatrixExit" {
        $katakana = @()
        for ($cp = 0xFF66; $cp -le 0xFF9D; $cp++) { $katakana += [char]$cp }
        $chars = $katakana + @('0','1','2','3','4','5','6','7','8','9') + @('A','B','C','D','E','F')

        $width = 80
        try { $width = $Host.UI.RawUI.WindowSize.Width } catch { $width = 80 }
        if ($width -lt 20) { $width = 80 }

        # "Matrix green" - true-color ANSI, brighter head / dimmer trail
        # chars mixed per frame for a flickering rain effect.
        $bright = "$([char]27)[38;2;170;255;170m"
        $mid    = "$([char]27)[38;2;0;255;65m"
        $dim    = "$([char]27)[38;2;0;110;30m"
        $reset  = "$([char]27)[0m"

        Clear-Host
        $rng = [System.Random]::new()
        $frames = 22
        for ($f = 0; $f -lt $frames; $f++) {
            $line = New-Object System.Text.StringBuilder
            for ($x = 0; $x -lt $width; $x++) {
                $ch = $chars[$rng.Next($chars.Count)]
                $roll = $rng.Next(100)
                if     ($roll -lt 8)  { [void]$line.Append($bright + $ch) }
                elseif ($roll -lt 55) { [void]$line.Append($mid    + $ch) }
                else                  { [void]$line.Append($dim    + $ch) }
            }
            [void]$line.Append($reset)
            Write-Host $line.ToString()
            Start-Sleep -Milliseconds 90
        }

        Start-Sleep -Milliseconds 300
        Clear-Host
        Write-Host ""
        if ($Lang -eq "EN") {
            Write-Host ("  " + $mid + "Goodbye. Happy gaming!" + $reset)
        } elseif ($Lang -eq "DE") {
            Write-Host ("  " + $mid + "Tschuess. Viel Spass beim Zocken!" + $reset)
        } else {
            Write-Host ("  " + $mid + "Goodbye! / Tschuess!" + $reset)
        }
        Write-Host ""
        Start-Sleep -Milliseconds 1200

        # "Follow melcom." - starts almost invisible (dark green, close to
        # black), then a brightness glow travels across the letters left to
        # right, fading each letter back to dark as it passes, then travels
        # back right to left the same way, ending dark again.
        $waveDarkRGB = @(0, 25, 9)
        $wavePeakRGB = @(0, 190, 68)
        $glowWidth   = 2.6

        $followText = "Follow melcom."
        $textLen    = $followText.Length
        $travelFrom = -3
        $travelTo   = $textLen + 2
        $stepsPerPass = 26

        for ($pass = 0; $pass -lt 2; $pass++) {
            for ($s = 0; $s -le $stepsPerPass; $s++) {
                $progress = $s / $stepsPerPass
                if ($pass -eq 0) {
                    $peakPos = $travelFrom + ($travelTo - $travelFrom) * $progress
                } else {
                    $peakPos = $travelTo + ($travelFrom - $travelTo) * $progress
                }

                $line2 = New-Object System.Text.StringBuilder
                [void]$line2.Append("  ")
                for ($ci = 0; $ci -lt $textLen; $ci++) {
                    $dist = [Math]::Abs($ci - $peakPos)
                    $t = [Math]::Max(0.0, 1.0 - ($dist / $glowWidth))
                    $r = [int]($waveDarkRGB[0] + ($wavePeakRGB[0] - $waveDarkRGB[0]) * $t)
                    $g = [int]($waveDarkRGB[1] + ($wavePeakRGB[1] - $waveDarkRGB[1]) * $t)
                    $b = [int]($waveDarkRGB[2] + ($wavePeakRGB[2] - $waveDarkRGB[2]) * $t)
                    $col = "$([char]27)[38;2;${r};${g};${b}m"
                    [void]$line2.Append($col + $followText[$ci])
                }
                [void]$line2.Append($reset)
                Write-Host ("`r" + $line2.ToString()) -NoNewline
                Start-Sleep -Milliseconds 45
            }
        }
        Write-Host ""
        Write-Host ""
        Start-Sleep -Milliseconds 1000
    }

    default {
        Write-Output "ERROR|UNKNOWN_ACTION"
    }
}