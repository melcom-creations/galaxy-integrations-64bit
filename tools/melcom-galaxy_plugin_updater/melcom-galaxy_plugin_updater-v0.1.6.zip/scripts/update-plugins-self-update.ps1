<# Self-update and recycle-only operations for the Galaxy Plugin Updater.
   Check is called inside one pre-parsed BAT block: after replacement that
   block must exit, never resume reading the old batch at its former offset.
   Library only defines functions; it does not access the network or files.
#>
param(
    [ValidateSet('Check','Library')][string]$Mode = 'Check',
    [string]$Root = (Split-Path -Parent $PSScriptRoot),
    [string]$CurrentVersion,
    [ValidateSet('EN','DE')][string]$Lang = 'EN'
)

function Get-UpdaterFileNames {
    @('CHANGELOG.md','licenses/LICENSE','README.md','update-plugins.bat',
      'scripts/update-plugins-helpers.ps1','scripts/update-plugins-self-update.ps1','scripts/update-plugins-recycle.cs')
}

function Assert-UpdaterLocalPath([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    $drive = New-Object IO.DriveInfo([IO.Path]::GetPathRoot($full))
    if ($drive.DriveType -ne [IO.DriveType]::Fixed) { throw 'A local fixed drive is required for safe recycling.' }
    $cursor = $full
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked path is not supported: $cursor" }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor.TrimEnd('\'))
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
    return $full
}

function Initialize-UpdaterRecycler {
    if ('GalaxyUpdater.RecycleOnly' -as [type]) { return }
    Add-Type -Path (Join-Path $PSScriptRoot 'update-plugins-recycle.cs')
}

function Move-ToUpdaterRecycleBin([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $full = Assert-UpdaterLocalPath $Path
    Initialize-UpdaterRecycler
    [GalaxyUpdater.RecycleOnly]::Send($full)
    if (Test-Path -LiteralPath $full) { throw "Item was not recycled: $full" }
}

function Get-UpdaterRelease([object[]]$Items, [string]$InstalledVersion) {
    if ($InstalledVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'Invalid installed updater version.' }
    $prefix = 'tools/melcom-galaxy_plugin_updater/'
    $candidates = @(foreach ($item in $Items) {
        if ($item.type -ne 'file' -or $item.name -cnotmatch '^melcom-galaxy_plugin_updater-v(\d+\.\d+\.\d+)\.zip$') { continue }
        $versionText = $Matches[1]
        if ($item.path -cne ($prefix + $item.name) -or $item.sha -notmatch '^[a-fA-F0-9]{40}$' -or $item.size -le 0 -or $item.size -gt 5242880) { continue }
        [pscustomobject]@{Version=$versionText; Number=[version]$versionText; Name=$item.name; Sha=$item.sha; Size=[long]$item.size;
            Url=('https://raw.githubusercontent.com/melcom-creations/galaxy-integrations-64bit/main/' + $prefix + $item.name)}
    })
    $latest = $candidates | Sort-Object Number -Descending | Select-Object -First 1
    if (-not $latest) { throw 'No valid updater ZIP found in the GitHub folder.' }
    [pscustomobject]@{Available=($latest.Number -gt [version]$InstalledVersion); Release=$latest}
}

function Get-UpdaterSHA256([string]$Path) {
    $stream=[IO.File]::OpenRead($Path)
    $sha=[Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','') }
    finally { $sha.Dispose(); $stream.Dispose() }
}

function Get-UpdaterGitBlobHash([string]$Path) {
    $data = [IO.File]::ReadAllBytes($Path)
    $header = [Text.Encoding]::ASCII.GetBytes(('blob ' + $data.Length + [char]0))
    $sha = [Security.Cryptography.SHA1]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash([byte[]]($header + $data)))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Expand-VerifiedUpdater([string]$Zip, [string]$Destination, [string]$Version) {
    if ($Version -notmatch '^\d+\.\d+\.\d+$') { throw 'Invalid release version.' }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $required = @(Get-UpdaterFileNames)
    $archive = [IO.Compression.ZipFile]::OpenRead($Zip)
    try {
        if (@($archive.Entries | Where-Object { $_.Name }).Count -ne $required.Count) { throw 'Unexpected updater ZIP contents.' }
        $seen = @{}
        $total = 0L
        foreach ($entry in $archive.Entries) {
            if (-not $entry.Name) {
                if ($entry.FullName -cnotin @('scripts/','licenses/')) { throw 'Unexpected ZIP directory.' }
                continue
            }
            if ($required -cnotcontains $entry.FullName -or $seen.ContainsKey($entry.FullName) -or $entry.Length -le 0) { throw 'Unsafe or unexpected ZIP entry.' }
            $seen[$entry.FullName] = $true
            $total += $entry.Length
            if ($total -gt 20971520) { throw 'Updater ZIP is too large.' }
        }
    } finally { $archive.Dispose() }
    if (Test-Path -LiteralPath $Destination) { throw 'Extraction destination already exists.' }
    [IO.Compression.ZipFile]::ExtractToDirectory($Zip,$Destination)
    $batch = [IO.File]::ReadAllText((Join-Path $Destination 'update-plugins.bat'))
    $versions = [regex]::Matches($batch,'(?m)^set "UPDATER_VERSION=(\d+\.\d+\.\d+)"\r?$')
    if ($versions.Count -ne 1 -or $versions[0].Groups[1].Value -cne $Version) { throw 'Updater ZIP version does not match its filename.' }
    $readme = [IO.File]::ReadAllText((Join-Path $Destination 'README.md'))
    if ($readme -notmatch ('(?m)^# melcom GOG Galaxy v2\.1\+ Plugin Updater v' + [regex]::Escape($Version) + '\r?$')) { throw 'README version mismatch.' }
    foreach ($name in @('scripts/update-plugins-helpers.ps1','scripts/update-plugins-self-update.ps1')) {
        $tokens=$null; $errors=$null
        [Management.Automation.Language.Parser]::ParseFile((Join-Path $Destination $name),[ref]$tokens,[ref]$errors) | Out-Null
        if ($errors.Count) { throw "Invalid PowerShell script: $name" }
    }
}

function Install-PreparedUpdater([string]$Target, [string]$Prepared, [string]$Workspace, [string]$InstalledVersion) {
    $Target = Assert-UpdaterLocalPath $Target
    $Workspace = Assert-UpdaterLocalPath $Workspace
    $boundary = $Target.TrimEnd('\') + '\.self-update\'
    if (-not $Workspace.StartsWith($boundary,[StringComparison]::OrdinalIgnoreCase) -or
        [IO.Path]::GetFullPath($Prepared) -ine (Join-Path $Workspace 'prepared')) { throw 'Invalid self-update workspace.' }
    $files = @(Get-UpdaterFileNames)
    foreach ($name in $files) {
        foreach ($base in @($Target,$Prepared)) {
            $path = Join-Path $base $name
            [void](Assert-UpdaterLocalPath $path)
            if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing updater file: $path" }
        }
    }
    $bat = [IO.File]::ReadAllText((Join-Path $Target 'update-plugins.bat'))
    if ($bat -notmatch ('(?m)^set "UPDATER_VERSION=' + [regex]::Escape($InstalledVersion) + '"\r?$')) { throw 'Installed updater changed during update preparation.' }
    $previous = Join-Path $Workspace ('previous-v' + $InstalledVersion)
    $failed = Join-Path $Workspace 'incomplete-new-version'
    [IO.Directory]::CreateDirectory($previous) | Out-Null
    $moved = New-Object 'System.Collections.Generic.List[string]'
    $created = New-Object 'System.Collections.Generic.List[string]'
    try {
        foreach ($name in $files) {
            [IO.Directory]::CreateDirectory((Split-Path -Parent (Join-Path $previous $name))) | Out-Null
            Move-Item -LiteralPath (Join-Path $Target $name) -Destination (Join-Path $previous $name) -ErrorAction Stop
            $moved.Add($name)
        }
        foreach ($name in $files) {
            $created.Add($name)
            Copy-UpdaterFile (Join-Path $Prepared $name) (Join-Path $Target $name)
            if ((Get-UpdaterSHA256 (Join-Path $Target $name)) -ne (Get-UpdaterSHA256 (Join-Path $Prepared $name))) { throw "Installed file hash mismatch: $name" }
        }
    } catch {
        $failure = $_.Exception.Message
        try {
            [IO.Directory]::CreateDirectory($failed) | Out-Null
            foreach ($name in $created) {
                $path = Join-Path $Target $name
                if (Test-Path -LiteralPath $path) { [IO.Directory]::CreateDirectory((Split-Path -Parent (Join-Path $failed $name))) | Out-Null; Move-Item -LiteralPath $path -Destination (Join-Path $failed $name) -ErrorAction Stop }
            }
            foreach ($name in $moved) { Move-Item -LiteralPath (Join-Path $previous $name) -Destination (Join-Path $Target $name) -ErrorAction Stop }
        } catch { throw "ROLLBACK_FAILED. Recovery files: $previous. $($_.Exception.Message)" }
        throw "Update canceled; previous version restored. $failure"
    }
    $recycled = $false
    try { Move-ToUpdaterRecycleBin $previous; $recycled=$true } catch { Write-Warning "Previous version retained at $previous. $($_.Exception.Message)" }
    return [pscustomobject]@{Recycled=$recycled; RecoveryPath=$previous}
}

function Copy-UpdaterFile([string]$Source, [string]$Destination) {
    [IO.Directory]::CreateDirectory((Split-Path -Parent $Destination)) | Out-Null
    [IO.File]::Copy($Source,$Destination,$false)
}

function Restart-GalaxyUpdater([string]$Target) {
    # Inherit this console so no hidden interactive prompt or extra window is needed.
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = $env:ComSpec
    $start.Arguments = '/d /s /c ""' + (Join-Path $Target 'update-plugins.bat') + '""'
    $start.WorkingDirectory = $Target
    $start.UseShellExecute = $false
    $process = [Diagnostics.Process]::Start($start)
    try { $process.WaitForExit() } finally { $process.Dispose() }
}

function Invoke-UpdaterSelfCheck([string]$Target, [string]$InstalledVersion, [string]$Language) {
    $de = $Language -eq 'DE'
    $workspace = $null; $mutex=$null; $owned=$false; $installed=$false; $keep=$false
    try {
        $searchAnswer=Read-Host $(if($de){'Nach Updates fuer den Plugin Updater suchen? [j/N]'}else{'Check for updates to the Plugin Updater? [y/N]'})
        if (($de -and $searchAnswer -ine 'j') -or (-not $de -and $searchAnswer -ine 'y')) { return 0 }
        Write-Host $(if($de){'Suche nach Updates fuer den Plugin Updater ...'}else{'Checking for Plugin Updater updates ...'}) -ForegroundColor Cyan
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $headers=@{'User-Agent'='melcom-galaxy-updater'; Accept='application/vnd.github+json'}
        if ($env:GITHUB_TOKEN) { $headers.Authorization='Bearer '+$env:GITHUB_TOKEN }
        $items=Invoke-RestMethod -UseBasicParsing -Uri 'https://api.github.com/repos/melcom-creations/galaxy-integrations-64bit/contents/tools/melcom-galaxy_plugin_updater?ref=main' -Headers $headers -TimeoutSec 15
        $check=Get-UpdaterRelease @($items) $InstalledVersion
        if (-not $check.Available) {
            Write-Host $(if($de){'Der Plugin Updater ist aktuell.'}else{'The Plugin Updater is up to date.'}) -ForegroundColor Green
            [void](Read-Host $(if($de){'Mit der Eingabetaste weiter zu den Plugins'}else{'Press Enter to continue to the plugins'}))
            return 0
        }
        $release=$check.Release
        Write-Host $(if($de){"Neue Updater-Version: $($release.Version) (installiert: $InstalledVersion)."}else{"New updater version: $($release.Version) (installed: $InstalledVersion)."}) -ForegroundColor Yellow
        Write-Host $(if($de){'Die bisherige Version kommt in den Papierkorb. Backups und Logs bleiben erhalten.'}else{'The previous version goes to the Recycle Bin. Backups and logs are kept.'})
        $answer=Read-Host $(if($de){'Jetzt aktualisieren und neu starten? [j/N]'}else{'Update and restart now? [y/N]'})
        if (($de -and $answer -ine 'j') -or (-not $de -and $answer -ine 'y')) { return 0 }
        $Target=Assert-UpdaterLocalPath $Target
        $sha=[Security.Cryptography.SHA256]::Create()
        try { $key=[BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Target.ToLowerInvariant()))).Replace('-','') } finally { $sha.Dispose() }
        $mutex=New-Object Threading.Mutex($false,('Local\melcom-updater-'+$key))
        try { $owned=$mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned=$true }
        if (-not $owned) { throw 'Another self-update is already in progress.' }
        $workspace=Join-Path $Target ('.self-update\'+[guid]::NewGuid().ToString('N'))
        [void](Assert-UpdaterLocalPath $workspace)
        [IO.Directory]::CreateDirectory($workspace) | Out-Null
        $zip=Join-Path $workspace $release.Name
        $ProgressPreference='SilentlyContinue'
        Invoke-WebRequest -UseBasicParsing -Uri $release.Url -OutFile $zip -Headers @{'User-Agent'='melcom-galaxy-updater'} -TimeoutSec 120
        if ((Get-Item -LiteralPath $zip).Length -ne $release.Size -or (Get-UpdaterGitBlobHash $zip) -ine $release.Sha) { throw 'Downloaded ZIP does not match GitHub metadata.' }
        $prepared=Join-Path $workspace 'prepared'
        Expand-VerifiedUpdater $zip $prepared $release.Version
        $result=Install-PreparedUpdater $Target $prepared $workspace $InstalledVersion
        $installed=$true; $keep=-not $result.Recycled
        Write-Host $(if($de){'Updater aktualisiert. Die neue Version wird gestartet.'}else{'Updater updated. Starting the new version.'}) -ForegroundColor Green
    } catch {
        $message=$_.Exception.Message
        if ($message -like 'ROLLBACK_FAILED*') { $keep=$true; Write-Host $message -ForegroundColor Red; [void](Read-Host 'Press Enter / Eingabetaste'); return 10 }
        Write-Host $(if($de){"Selbstupdate nicht moeglich: $message"}else{"Self-update unavailable: $message"}) -ForegroundColor Yellow
        if ($workspace) { $keep=$true; Write-Host "Recovery / Diagnose: $workspace" }
        [void](Read-Host $(if($de){'Mit der Eingabetaste weiter zu den Plugins'}else{'Press Enter to continue to the plugins'}))
    } finally {
        if ($workspace -and -not $keep -and (Test-Path -LiteralPath $workspace)) {
            try { Move-ToUpdaterRecycleBin $workspace } catch { Write-Warning "Files retained at $workspace. $($_.Exception.Message)" }
        }
        if ($owned) { $mutex.ReleaseMutex() }
        if ($mutex) { $mutex.Dispose() }
    }
    if ($installed) {
        try { Restart-GalaxyUpdater $Target } catch { Write-Host "Restart manually / Bitte neu starten: $Target" -ForegroundColor Yellow; [void](Read-Host 'Press Enter / Eingabetaste') }
        return 10
    }
    return 0
}

if ($Mode -eq 'Check') {
    $ErrorActionPreference='Stop'
    $status=Invoke-UpdaterSelfCheck $Root $CurrentVersion $Lang
    exit $status
}
